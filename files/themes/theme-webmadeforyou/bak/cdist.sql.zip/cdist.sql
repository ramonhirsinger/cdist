-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3306
-- Erstellungszeit: 04. Mai 2017 um 11:13
-- Server-Version: 5.6.34-log
-- PHP-Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cdist`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_article`
--

CREATE TABLE IF NOT EXISTS `tl_article` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `inColumn` varchar(32) NOT NULL DEFAULT '',
  `keywords` text,
  `showTeaser` char(1) NOT NULL DEFAULT '',
  `teaserCssID` varchar(255) NOT NULL DEFAULT '',
  `teaser` text,
  `printable` varchar(255) NOT NULL DEFAULT '',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `guests` char(1) NOT NULL DEFAULT '',
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `space` varchar(64) NOT NULL DEFAULT '',
  `published` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_article`
--

INSERT INTO `tl_article` (`id`, `pid`, `sorting`, `tstamp`, `title`, `alias`, `author`, `inColumn`, `keywords`, `showTeaser`, `teaserCssID`, `teaser`, `printable`, `customTpl`, `protected`, `groups`, `guests`, `cssID`, `space`, `published`, `start`, `stop`) VALUES
(1, 2, 128, 1493889210, 'Seite - 1', 'seite-1', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(2, 3, 128, 1493895043, 'Seite - 2', 'seite-2', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(3, 4, 128, 1493895058, 'Seite - 3', 'seite-3', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(4, 5, 128, 1493895074, 'Seite - 4', 'seite-4', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(5, 6, 128, 1493895097, 'Seite - 5', 'seite-5', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(6, 7, 128, 1493895128, 'Footer - 1', 'footer-1', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(7, 8, 128, 1493895146, 'Footer - 2', 'footer-2', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(8, 9, 128, 1493895166, 'Footer - 3', 'footer-3', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(9, 11, 128, 1493895480, 'Seite - 3 - 1', 'seite-3-1', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(10, 12, 128, 1493895492, 'Seite - 3 - 2', 'seite-3-2', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '1', '', ''),
(11, 14, 128, 1493895544, '404', 'id-404', 1, 'main', NULL, '', '', NULL, '', '', '', NULL, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_calendar`
--

CREATE TABLE IF NOT EXISTS `tl_calendar` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `allowComments` char(1) NOT NULL DEFAULT '',
  `notify` varchar(32) NOT NULL DEFAULT '',
  `sortOrder` varchar(32) NOT NULL DEFAULT '',
  `perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moderate` char(1) NOT NULL DEFAULT '',
  `bbcode` char(1) NOT NULL DEFAULT '',
  `requireLogin` char(1) NOT NULL DEFAULT '',
  `disableCaptcha` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_calendar_events`
--

CREATE TABLE IF NOT EXISTS `tl_calendar_events` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `addTime` char(1) NOT NULL DEFAULT '',
  `startTime` int(10) unsigned DEFAULT NULL,
  `endTime` int(10) unsigned DEFAULT NULL,
  `startDate` int(10) unsigned DEFAULT NULL,
  `endDate` int(10) unsigned DEFAULT NULL,
  `location` varchar(255) NOT NULL DEFAULT '',
  `teaser` text,
  `addImage` char(1) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `size` varchar(64) NOT NULL DEFAULT '',
  `imagemargin` varchar(128) NOT NULL DEFAULT '',
  `imageUrl` varchar(255) NOT NULL DEFAULT '',
  `fullsize` char(1) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `floating` varchar(32) NOT NULL DEFAULT '',
  `recurring` char(1) NOT NULL DEFAULT '',
  `repeatEach` varchar(64) NOT NULL DEFAULT '',
  `repeatEnd` int(10) unsigned NOT NULL DEFAULT '0',
  `recurrences` smallint(5) unsigned NOT NULL DEFAULT '0',
  `addEnclosure` char(1) NOT NULL DEFAULT '',
  `enclosure` blob,
  `source` varchar(32) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `articleId` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `target` char(1) NOT NULL DEFAULT '',
  `cssClass` varchar(255) NOT NULL DEFAULT '',
  `noComments` char(1) NOT NULL DEFAULT '',
  `published` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_calendar_feed`
--

CREATE TABLE IF NOT EXISTS `tl_calendar_feed` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `language` varchar(32) NOT NULL DEFAULT '',
  `calendars` blob,
  `format` varchar(32) NOT NULL DEFAULT '',
  `source` varchar(32) NOT NULL DEFAULT '',
  `maxItems` smallint(5) unsigned NOT NULL DEFAULT '0',
  `feedBase` varchar(255) NOT NULL DEFAULT '',
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_comments`
--

CREATE TABLE IF NOT EXISTS `tl_comments` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `date` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(128) NOT NULL DEFAULT '',
  `comment` text,
  `addReply` char(1) NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `reply` text,
  `published` char(1) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `notified` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_comments_notify`
--

CREATE TABLE IF NOT EXISTS `tl_comments_notify` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `addedOn` varchar(10) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `tokenConfirm` varchar(32) NOT NULL DEFAULT '',
  `tokenRemove` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_content`
--

CREATE TABLE IF NOT EXISTS `tl_content` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `ptable` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) NOT NULL DEFAULT '',
  `headline` varchar(255) NOT NULL DEFAULT '',
  `text` mediumtext,
  `addImage` char(1) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `size` varchar(64) NOT NULL DEFAULT '',
  `imagemargin` varchar(128) NOT NULL DEFAULT '',
  `imageUrl` varchar(255) NOT NULL DEFAULT '',
  `fullsize` char(1) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `floating` varchar(32) NOT NULL DEFAULT '',
  `html` mediumtext,
  `listtype` varchar(32) NOT NULL DEFAULT '',
  `listitems` blob,
  `tableitems` mediumblob,
  `summary` varchar(255) NOT NULL DEFAULT '',
  `thead` char(1) NOT NULL DEFAULT '',
  `tfoot` char(1) NOT NULL DEFAULT '',
  `tleft` char(1) NOT NULL DEFAULT '',
  `sortable` char(1) NOT NULL DEFAULT '',
  `sortIndex` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortOrder` varchar(32) NOT NULL DEFAULT '',
  `mooHeadline` varchar(255) NOT NULL DEFAULT '',
  `mooStyle` varchar(255) NOT NULL DEFAULT '',
  `mooClasses` varchar(255) NOT NULL DEFAULT '',
  `highlight` varchar(32) NOT NULL DEFAULT '',
  `shClass` varchar(255) NOT NULL DEFAULT '',
  `code` text,
  `url` varchar(255) NOT NULL DEFAULT '',
  `target` char(1) NOT NULL DEFAULT '',
  `titleText` varchar(255) NOT NULL DEFAULT '',
  `linkTitle` varchar(255) NOT NULL DEFAULT '',
  `embed` varchar(255) NOT NULL DEFAULT '',
  `rel` varchar(64) NOT NULL DEFAULT '',
  `useImage` char(1) NOT NULL DEFAULT '',
  `multiSRC` blob,
  `orderSRC` blob,
  `useHomeDir` char(1) NOT NULL DEFAULT '',
  `perRow` smallint(5) unsigned NOT NULL DEFAULT '0',
  `perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `numberOfItems` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortBy` varchar(32) NOT NULL DEFAULT '',
  `metaIgnore` char(1) NOT NULL DEFAULT '',
  `galleryTpl` varchar(64) NOT NULL DEFAULT '',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `playerSRC` blob,
  `youtube` varchar(16) NOT NULL DEFAULT '',
  `posterSRC` binary(16) DEFAULT NULL,
  `playerSize` varchar(64) NOT NULL DEFAULT '',
  `autoplay` char(1) NOT NULL DEFAULT '',
  `sliderDelay` int(10) unsigned NOT NULL DEFAULT '0',
  `sliderSpeed` int(10) unsigned NOT NULL DEFAULT '300',
  `sliderStartSlide` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sliderContinuous` char(1) NOT NULL DEFAULT '',
  `cteAlias` int(10) unsigned NOT NULL DEFAULT '0',
  `articleAlias` int(10) unsigned NOT NULL DEFAULT '0',
  `article` int(10) unsigned NOT NULL DEFAULT '0',
  `form` int(10) unsigned NOT NULL DEFAULT '0',
  `module` int(10) unsigned NOT NULL DEFAULT '0',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `guests` char(1) NOT NULL DEFAULT '',
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `space` varchar(64) NOT NULL DEFAULT '',
  `invisible` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `com_order` varchar(32) NOT NULL DEFAULT '',
  `com_perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `com_moderate` char(1) NOT NULL DEFAULT '',
  `com_bbcode` char(1) NOT NULL DEFAULT '',
  `com_disableCaptcha` char(1) NOT NULL DEFAULT '',
  `com_requireLogin` char(1) NOT NULL DEFAULT '',
  `com_template` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_cron`
--

CREATE TABLE IF NOT EXISTS `tl_cron` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `value` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_cron`
--

INSERT INTO `tl_cron` (`id`, `name`, `value`) VALUES
(1, 'lastrun', '1493887020'),
(2, 'monthly', '201705'),
(3, 'weekly', '201718'),
(4, 'daily', '20170504'),
(5, 'hourly', '0'),
(6, 'minutely', '0');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_extension`
--

CREATE TABLE IF NOT EXISTS `tl_extension` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(64) NOT NULL DEFAULT '',
  `folder` varchar(48) NOT NULL DEFAULT '',
  `author` varchar(128) NOT NULL DEFAULT '',
  `copyright` varchar(128) NOT NULL DEFAULT '',
  `package` varchar(64) NOT NULL DEFAULT '',
  `license` varchar(64) NOT NULL DEFAULT '',
  `addBeMod` char(1) NOT NULL DEFAULT '',
  `beClasses` varchar(255) NOT NULL DEFAULT '',
  `beTables` varchar(255) NOT NULL DEFAULT '',
  `beTemplates` varchar(255) NOT NULL DEFAULT '',
  `addFeMod` char(1) NOT NULL DEFAULT '',
  `feClasses` varchar(255) NOT NULL DEFAULT '',
  `feTables` varchar(255) NOT NULL DEFAULT '',
  `feTemplates` varchar(255) NOT NULL DEFAULT '',
  `addLanguage` char(1) NOT NULL DEFAULT '',
  `languages` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_faq`
--

CREATE TABLE IF NOT EXISTS `tl_faq` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `answer` text,
  `addImage` char(1) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `size` varchar(64) NOT NULL DEFAULT '',
  `imagemargin` varchar(128) NOT NULL DEFAULT '',
  `imageUrl` varchar(255) NOT NULL DEFAULT '',
  `fullsize` char(1) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `floating` varchar(12) NOT NULL DEFAULT '',
  `addEnclosure` char(1) NOT NULL DEFAULT '',
  `enclosure` blob,
  `noComments` char(1) NOT NULL DEFAULT '',
  `published` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_faq_category`
--

CREATE TABLE IF NOT EXISTS `tl_faq_category` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `headline` varchar(255) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `allowComments` char(1) NOT NULL DEFAULT '',
  `notify` varchar(16) NOT NULL DEFAULT '',
  `sortOrder` varchar(12) NOT NULL DEFAULT '',
  `perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moderate` char(1) NOT NULL DEFAULT '',
  `bbcode` char(1) NOT NULL DEFAULT '',
  `requireLogin` char(1) NOT NULL DEFAULT '',
  `disableCaptcha` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_files`
--

CREATE TABLE IF NOT EXISTS `tl_files` (
  `id` int(10) unsigned NOT NULL,
  `pid` binary(16) DEFAULT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `uuid` binary(16) DEFAULT NULL,
  `type` varchar(16) NOT NULL DEFAULT '',
  `path` varchar(1022) NOT NULL DEFAULT '',
  `extension` varchar(16) NOT NULL DEFAULT '',
  `hash` varchar(32) NOT NULL DEFAULT '',
  `found` char(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `importantPartX` int(10) NOT NULL DEFAULT '0',
  `importantPartY` int(10) NOT NULL DEFAULT '0',
  `importantPartWidth` int(10) NOT NULL DEFAULT '0',
  `importantPartHeight` int(10) NOT NULL DEFAULT '0',
  `meta` blob
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_files`
--

INSERT INTO `tl_files` (`id`, `pid`, `tstamp`, `uuid`, `type`, `path`, `extension`, `hash`, `found`, `name`, `importantPartX`, `importantPartY`, `importantPartWidth`, `importantPartHeight`, `meta`) VALUES
(1, NULL, 1493763367, 0xf0556d412f8411e7b21454ee75878161, 'folder', 'files/tiny_templates', '', 'eacf331f0ffc35d4b482f1d15a887d3b', '1', 'tiny_templates', 0, 0, 0, 0, NULL),
(2, 0xf0556d412f8411e7b21454ee75878161, 1493763367, 0xf0556d342f8411e7b21454ee75878161, 'file', 'files/tiny_templates/index.html', 'html', 'aeebec42dc0335ea1e0853f4393259b4', '1', 'index.html', 0, 0, 0, 0, NULL),
(3, NULL, 1493763367, 0xf0556d272f8411e7b21454ee75878161, 'file', 'files/tinymce.css', 'css', 'e6cfd2993ed50341da010e66be287d2d', '1', 'tinymce.css', 0, 0, 0, 0, NULL),
(4, NULL, 1493888027, 0x2f9d4e1230a711e7b6fb54ee75878161, 'folder', 'files/webmadeforyou', '', 'eb9f98a5e6ebcee55b521f52362a4fa6', '1', 'webmadeforyou', 0, 0, 0, 0, NULL),
(5, 0x2f9d4e1230a711e7b6fb54ee75878161, 1493888027, 0x2f9d4dd730a711e7b6fb54ee75878161, 'file', 'files/webmadeforyou/.htaccess', 'htaccess', 'bff88aa9f255706dd1e53e330cb1a7b7', '1', '.htaccess', 0, 0, 0, 0, NULL),
(6, 0x2f9d4e1230a711e7b6fb54ee75878161, 1493888333, 0xe642901230a711e7b6fb54ee75878161, 'folder', 'files/webmadeforyou/template', '', '45f2b817eb9edaee3ada4abb724fbcc3', '1', 'template', 0, 0, 0, 0, NULL),
(7, 0xe642901230a711e7b6fb54ee75878161, 1493888333, 0xe642900130a711e7b6fb54ee75878161, 'file', 'files/webmadeforyou/template/webmadeforyou_logo.png', 'png', '1d154344a85885d73cf85e6b3255a973', '1', 'webmadeforyou_logo.png', 0, 0, 0, 0, NULL),
(8, 0xe642901230a711e7b6fb54ee75878161, 1493888572, 0x746cf9b030a811e7b6fb54ee75878161, 'file', 'files/webmadeforyou/template/webmadeforyou_logo_72x80.jpg', 'jpg', '64ba5bd5c189fe518ec4413e156b7a82', '1', 'webmadeforyou_logo_72x80.jpg', 0, 0, 0, 0, NULL),
(9, NULL, 1493888918, 0x42e883ce30a911e7b6fb54ee75878161, 'folder', 'files/themes', '', 'df194e4211ed6bccb3f51a2a690d4679', '1', 'themes', 0, 0, 0, 0, NULL),
(10, 0x42e883ce30a911e7b6fb54ee75878161, 1493888918, 0x42e883c130a911e7b6fb54ee75878161, 'folder', 'files/themes/theme-webmadeforyou', '', '84d2742f5c64d0cc0466eca4305de753', '1', 'theme-webmadeforyou', 0, 0, 0, 0, NULL),
(11, 0x42e883c130a911e7b6fb54ee75878161, 1493888918, 0x42e883b930a911e7b6fb54ee75878161, 'folder', 'files/themes/theme-webmadeforyou/images', '', '45f2b817eb9edaee3ada4abb724fbcc3', '1', 'images', 0, 0, 0, 0, NULL),
(12, 0x42e883b930a911e7b6fb54ee75878161, 1493888918, 0x42e883b030a911e7b6fb54ee75878161, 'file', 'files/themes/theme-webmadeforyou/images/webmadeforyou_logo_72x80.jpg', 'jpg', '64ba5bd5c189fe518ec4413e156b7a82', '1', 'webmadeforyou_logo_72x80.jpg', 0, 0, 0, 0, NULL),
(13, 0x42e883c130a911e7b6fb54ee75878161, 1493889245, 0x057e6fe330aa11e7b6fb54ee75878161, 'folder', 'files/themes/theme-webmadeforyou/templates', '', 'd41d8cd98f00b204e9800998ecf8427e', '1', 'templates', 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_form`
--

CREATE TABLE IF NOT EXISTS `tl_form` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `sendViaEmail` char(1) NOT NULL DEFAULT '',
  `recipient` varchar(1022) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `format` varchar(12) NOT NULL DEFAULT '',
  `skipEmpty` char(1) NOT NULL DEFAULT '',
  `storeValues` char(1) NOT NULL DEFAULT '',
  `targetTable` varchar(64) NOT NULL DEFAULT '',
  `method` varchar(12) NOT NULL DEFAULT '',
  `novalidate` char(1) NOT NULL DEFAULT '',
  `attributes` varchar(255) NOT NULL DEFAULT '',
  `formID` varchar(64) NOT NULL DEFAULT '',
  `tableless` char(1) NOT NULL DEFAULT '',
  `allowTags` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_form_field`
--

CREATE TABLE IF NOT EXISTS `tl_form_field` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `invisible` char(1) NOT NULL DEFAULT '',
  `type` varchar(64) NOT NULL DEFAULT '',
  `name` varchar(64) NOT NULL DEFAULT '',
  `label` varchar(255) NOT NULL DEFAULT '',
  `text` text,
  `html` text,
  `options` blob,
  `mandatory` char(1) NOT NULL DEFAULT '',
  `rgxp` varchar(32) NOT NULL DEFAULT '',
  `placeholder` varchar(255) NOT NULL DEFAULT '',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `size` varchar(255) NOT NULL DEFAULT '',
  `multiple` char(1) NOT NULL DEFAULT '',
  `mSize` smallint(5) unsigned NOT NULL DEFAULT '0',
  `extensions` varchar(255) NOT NULL DEFAULT '',
  `storeFile` char(1) NOT NULL DEFAULT '',
  `uploadFolder` binary(16) DEFAULT NULL,
  `useHomeDir` char(1) NOT NULL DEFAULT '',
  `doNotOverwrite` char(1) NOT NULL DEFAULT '',
  `fsType` varchar(32) NOT NULL DEFAULT '',
  `class` varchar(255) NOT NULL DEFAULT '',
  `value` varchar(255) NOT NULL DEFAULT '',
  `accesskey` char(1) NOT NULL DEFAULT '',
  `tabindex` smallint(5) unsigned NOT NULL DEFAULT '0',
  `fSize` smallint(5) unsigned NOT NULL DEFAULT '0',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `addSubmit` char(1) NOT NULL DEFAULT '',
  `slabel` varchar(255) NOT NULL DEFAULT '',
  `imageSubmit` char(1) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_image_size`
--

CREATE TABLE IF NOT EXISTS `tl_image_size` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) DEFAULT NULL,
  `sizes` varchar(255) NOT NULL DEFAULT '',
  `densities` varchar(255) NOT NULL DEFAULT '',
  `width` int(10) DEFAULT NULL,
  `height` int(10) DEFAULT NULL,
  `resizeMode` varchar(255) NOT NULL DEFAULT '',
  `zoom` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_image_size_item`
--

CREATE TABLE IF NOT EXISTS `tl_image_size_item` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `media` varchar(255) NOT NULL DEFAULT '',
  `sizes` varchar(255) NOT NULL DEFAULT '',
  `densities` varchar(255) NOT NULL DEFAULT '',
  `width` int(10) DEFAULT NULL,
  `height` int(10) DEFAULT NULL,
  `resizeMode` varchar(255) NOT NULL DEFAULT '',
  `zoom` int(10) DEFAULT NULL,
  `invisible` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_layout`
--

CREATE TABLE IF NOT EXISTS `tl_layout` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `rows` varchar(8) NOT NULL DEFAULT '',
  `headerHeight` varchar(255) NOT NULL DEFAULT '',
  `footerHeight` varchar(255) NOT NULL DEFAULT '',
  `cols` varchar(8) NOT NULL DEFAULT '',
  `widthLeft` varchar(255) NOT NULL DEFAULT '',
  `widthRight` varchar(255) NOT NULL DEFAULT '',
  `sections` varchar(1022) NOT NULL DEFAULT '',
  `sPosition` varchar(32) NOT NULL DEFAULT '',
  `framework` varchar(255) NOT NULL DEFAULT '',
  `stylesheet` blob,
  `external` blob,
  `orderExt` blob,
  `loadingOrder` varchar(16) NOT NULL DEFAULT '',
  `newsfeeds` blob,
  `calendarfeeds` blob,
  `modules` blob,
  `template` varchar(64) NOT NULL DEFAULT '',
  `doctype` varchar(32) NOT NULL DEFAULT '',
  `webfonts` varchar(255) NOT NULL DEFAULT '',
  `picturefill` char(1) NOT NULL DEFAULT '',
  `viewport` varchar(255) NOT NULL DEFAULT '',
  `titleTag` varchar(255) NOT NULL DEFAULT '',
  `cssClass` varchar(255) NOT NULL DEFAULT '',
  `onload` varchar(255) NOT NULL DEFAULT '',
  `head` text,
  `addJQuery` char(1) NOT NULL DEFAULT '',
  `jSource` varchar(16) NOT NULL DEFAULT '',
  `jquery` text,
  `addMooTools` char(1) NOT NULL DEFAULT '',
  `mooSource` varchar(16) NOT NULL DEFAULT '',
  `mootools` text,
  `analytics` text,
  `script` text,
  `static` char(1) NOT NULL DEFAULT '',
  `width` varchar(255) NOT NULL DEFAULT '',
  `align` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_layout`
--

INSERT INTO `tl_layout` (`id`, `pid`, `tstamp`, `name`, `rows`, `headerHeight`, `footerHeight`, `cols`, `widthLeft`, `widthRight`, `sections`, `sPosition`, `framework`, `stylesheet`, `external`, `orderExt`, `loadingOrder`, `newsfeeds`, `calendarfeeds`, `modules`, `template`, `doctype`, `webfonts`, `picturefill`, `viewport`, `titleTag`, `cssClass`, `onload`, `head`, `addJQuery`, `jSource`, `jquery`, `addMooTools`, `mooSource`, `mootools`, `analytics`, `script`, `static`, `width`, `align`) VALUES
(1, 1, 1493895977, 'layout-col-100', '3rw', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '1cl', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '', 'Unter der Kopfzeile', 'before', '', NULL, NULL, 0x613a313a7b693a303b733a303a22223b7d, 'external_first', NULL, NULL, 0x613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d, 'fe_page_100', 'html5', '', '', '', '', '', '', NULL, '', '', NULL, '', 'moo_local', NULL, NULL, NULL, '', '', 'center'),
(3, 1, 1493896220, 'layout-col-30-70', '3rw', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '2cll', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '', 'Unter der Kopfzeile', 'before', 'a:2:{i:0;s:10:"layout.css";i:1;s:14:"responsive.css";}', NULL, NULL, 0x613a313a7b693a303b733a303a22223b7d, 'external_first', NULL, NULL, 0x613a353a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226c656674223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a343b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d, 'fe_page_30_70', 'html5', '', '', '', '', '', '', NULL, '', '', NULL, '', 'moo_local', NULL, NULL, NULL, '', '', 'center'),
(4, 1, 1493896287, 'layout-col-40-60', '3rw', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '2cll', 'a:2:{s:4:"unit";s:0:"";s:5:"value";s:0:"";}', '', 'Unter der Kopfzeile', 'before', 'a:2:{i:0;s:10:"layout.css";i:1;s:14:"responsive.css";}', NULL, NULL, 0x613a313a7b693a303b733a303a22223b7d, 'external_first', NULL, NULL, 0x613a353a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226c656674223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d693a343b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d, 'fe_page_40_60', 'html5', '', '', '', '', '', '', NULL, '', '', NULL, '', 'moo_local', NULL, NULL, NULL, '', '', 'center');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_log`
--

CREATE TABLE IF NOT EXISTS `tl_log` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `source` varchar(32) NOT NULL DEFAULT '',
  `action` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `text` text,
  `func` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `browser` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_log`
--

INSERT INTO `tl_log` (`id`, `tstamp`, `source`, `action`, `username`, `text`, `func`, `ip`, `browser`) VALUES
(1, 1493889519, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the system log', 'Contao\\Automator::purgeSystemLog', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(2, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the page cache', 'Contao\\Automator::purgePageCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(3, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the image cache', 'Contao\\Automator::purgeImageCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(4, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the page cache', 'Contao\\Automator::purgePageCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(5, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the script cache', 'Contao\\Automator::purgeScriptCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(6, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the page cache', 'Contao\\Automator::purgePageCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(7, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the search cache', 'Contao\\Automator::purgeSearchCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(8, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the internal cache', 'Contao\\Automator::purgeInternalCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(9, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the temp folder', 'Contao\\Automator::purgeTempFolder', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(10, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(11, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Purged the page cache', 'Contao\\Automator::purgePageCache', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(12, 1493889520, 'BE', 'CRON', 'ramon.hirsinger', 'Regenerated the XML files', 'Contao\\Automator::generateXmlFiles', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(13, 1493889543, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_theme.id=1&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(14, 1493889624, 'BE', 'CONFIGURATION', 'ramon.hirsinger', 'The global configuration variable &quot;displayErrors&quot; has been changed from &quot;true&quot; to &quot;&quot;', 'Contao\\DC_File::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(15, 1493889624, 'BE', 'CONFIGURATION', 'ramon.hirsinger', 'The global configuration variable &quot;logErrors&quot; has been changed from &quot;true&quot; to &quot;&quot;', 'Contao\\DC_File::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(16, 1493890043, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_theme.id=1&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(17, 1493890161, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(18, 1493890179, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(19, 1493890183, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(20, 1493890202, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 3 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(21, 1493890249, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/fe_page.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/fe_page_layout-col-100.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(22, 1493891438, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 4 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(23, 1493891494, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/mod_navigation.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/webmadeforyou_mod_navigation.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(24, 1493891505, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/fe_page_layout-col-100.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/webmadeforyou_fe_page_layout-col-100.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(25, 1493891552, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/mod_navigation.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/webmadeforyou_mod_footernavigation.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(26, 1493891593, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 5 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(27, 1493891598, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_page.id=2&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(28, 1493891618, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(29, 1493891618, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_page.id=2&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(30, 1493891707, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 6 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(31, 1493894703, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(32, 1493894806, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/mod_navigation.html5&quot; has been deleted', 'Contao\\DC_Folder::delete', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(33, 1493894830, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/mod_navigation.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/mod_headnavigation.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(34, 1493894838, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(35, 1493894857, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(36, 1493894860, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 3 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(37, 1493894879, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 4 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(38, 1493894900, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/mod_navigation.html5&quot; has been deleted', 'Contao\\DC_Folder::delete', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(39, 1493894922, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/mod_navigation.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/mod_footernavigation.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(40, 1493894930, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/mod_headnavigation.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/mod_headernavigation.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(41, 1493894942, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(42, 1493894958, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(43, 1493894994, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(44, 1493895023, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=3&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(45, 1493895043, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(46, 1493895043, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=4&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(47, 1493895058, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(48, 1493895062, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=5&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(49, 1493895074, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(50, 1493895086, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=6&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(51, 1493895097, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(52, 1493895102, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=7&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(53, 1493895128, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(54, 1493895129, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=8&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(55, 1493895146, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(56, 1493895153, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=9&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(57, 1493895166, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(58, 1493895181, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=10&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(59, 1493895219, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 3 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(60, 1493895240, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 4 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(61, 1493895243, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_module.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(62, 1493895256, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_module.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(63, 1493895344, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_module.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(64, 1493895344, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_module.id=4&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(65, 1493895384, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 5 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(66, 1493895404, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 5 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(67, 1493895413, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 3 of record &quot;tl_module.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(68, 1493895424, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 6 of record &quot;tl_module.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(69, 1493895458, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=11&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(70, 1493895480, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(71, 1493895480, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=12&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(72, 1493895492, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(73, 1493895503, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=13&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(74, 1493895536, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_page.id=14&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(75, 1493895544, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(76, 1493895545, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_page.id=14&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(77, 1493895578, 'BE', 'CRON', 'ramon.hirsinger', 'Generated sitemap &quot;sitemap.xml&quot;', 'Contao\\Automator::generateSitemap', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(78, 1493895578, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_page.id=14&quot; has been created', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(79, 1493895673, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 7 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(80, 1493895686, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 8 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(81, 1493895714, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 4 of record &quot;tl_module.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(82, 1493895854, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_user_group.id=1&quot; has been created', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(83, 1493895930, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_layout.id=2&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(84, 1493895977, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 9 of record &quot;tl_layout.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(85, 1493896064, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/fe_page.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/fe_page_40_60.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(86, 1493896096, 'BE', 'FILES', 'ramon.hirsinger', 'File or folder &quot;templates/templates-webmadeforyou/fe_page.html5&quot; has been renamed to &quot;templates/templates-webmadeforyou/fe_page_30_70.html5&quot;', 'Contao\\DC_Folder::save', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(87, 1493896109, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_layout.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\DC_Table::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(88, 1493896119, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_layout.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(89, 1493896184, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 2 of record &quot;tl_layout.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(90, 1493896220, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 3 of record &quot;tl_layout.id=3&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(91, 1493896226, 'BE', 'GENERAL', 'ramon.hirsinger', 'A new entry &quot;tl_layout.id=4&quot; has been created by duplicating record &quot;tl_layout.id=3&quot; (parent records: tl_theme.id=1)', 'Contao\\DC_Table::copy', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(92, 1493896287, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 1 of record &quot;tl_layout.id=4&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36'),
(93, 1493896334, 'BE', 'GENERAL', 'ramon.hirsinger', 'Version 6 of record &quot;tl_module.id=1&quot; has been created (parent records: tl_theme.id=1)', 'Contao\\Versions::create', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_member`
--

CREATE TABLE IF NOT EXISTS `tl_member` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `firstname` varchar(255) NOT NULL DEFAULT '',
  `lastname` varchar(255) NOT NULL DEFAULT '',
  `dateOfBirth` varchar(11) NOT NULL DEFAULT '',
  `gender` varchar(32) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `street` varchar(255) NOT NULL DEFAULT '',
  `postal` varchar(32) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(64) NOT NULL DEFAULT '',
  `country` varchar(2) NOT NULL DEFAULT '',
  `phone` varchar(64) NOT NULL DEFAULT '',
  `mobile` varchar(64) NOT NULL DEFAULT '',
  `fax` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(5) NOT NULL DEFAULT '',
  `groups` blob,
  `login` char(1) NOT NULL DEFAULT '',
  `username` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(128) NOT NULL DEFAULT '',
  `assignDir` char(1) NOT NULL DEFAULT '',
  `homeDir` binary(16) DEFAULT NULL,
  `disable` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `dateAdded` int(10) unsigned NOT NULL DEFAULT '0',
  `lastLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `currentLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `loginCount` smallint(5) unsigned NOT NULL DEFAULT '3',
  `locked` int(10) unsigned NOT NULL DEFAULT '0',
  `session` blob,
  `autologin` varchar(32) DEFAULT NULL,
  `createdOn` int(10) unsigned NOT NULL DEFAULT '0',
  `activation` varchar(32) NOT NULL DEFAULT '',
  `newsletter` blob
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_member_group`
--

CREATE TABLE IF NOT EXISTS `tl_member_group` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `redirect` char(1) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `disable` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_module`
--

CREATE TABLE IF NOT EXISTS `tl_module` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `headline` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(64) NOT NULL DEFAULT '',
  `levelOffset` smallint(5) unsigned NOT NULL DEFAULT '0',
  `showLevel` smallint(5) unsigned NOT NULL DEFAULT '0',
  `hardLimit` char(1) NOT NULL DEFAULT '',
  `showProtected` char(1) NOT NULL DEFAULT '',
  `defineRoot` char(1) NOT NULL DEFAULT '',
  `rootPage` int(10) unsigned NOT NULL DEFAULT '0',
  `navigationTpl` varchar(64) NOT NULL DEFAULT '',
  `customTpl` varchar(64) NOT NULL DEFAULT '',
  `pages` blob,
  `orderPages` blob,
  `showHidden` char(1) NOT NULL DEFAULT '',
  `customLabel` varchar(64) NOT NULL DEFAULT '',
  `autologin` char(1) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `redirectBack` char(1) NOT NULL DEFAULT '',
  `cols` varchar(32) NOT NULL DEFAULT '',
  `editable` blob,
  `memberTpl` varchar(64) NOT NULL DEFAULT '',
  `tableless` char(1) NOT NULL DEFAULT '',
  `form` int(10) unsigned NOT NULL DEFAULT '0',
  `queryType` varchar(32) NOT NULL DEFAULT '',
  `fuzzy` char(1) NOT NULL DEFAULT '',
  `contextLength` smallint(5) unsigned NOT NULL DEFAULT '0',
  `totalLength` smallint(5) unsigned NOT NULL DEFAULT '0',
  `perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `searchType` varchar(32) NOT NULL DEFAULT '',
  `searchTpl` varchar(64) NOT NULL DEFAULT '',
  `inColumn` varchar(32) NOT NULL DEFAULT '',
  `skipFirst` smallint(5) unsigned NOT NULL DEFAULT '0',
  `loadFirst` char(1) NOT NULL DEFAULT '',
  `size` varchar(64) NOT NULL DEFAULT '',
  `transparent` char(1) NOT NULL DEFAULT '',
  `flashvars` varchar(255) NOT NULL DEFAULT '',
  `altContent` text,
  `source` varchar(32) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  `interactive` char(1) NOT NULL DEFAULT '',
  `flashID` varchar(64) NOT NULL DEFAULT '',
  `flashJS` text,
  `imgSize` varchar(64) NOT NULL DEFAULT '',
  `useCaption` char(1) NOT NULL DEFAULT '',
  `fullsize` char(1) NOT NULL DEFAULT '',
  `multiSRC` blob,
  `orderSRC` blob,
  `html` text,
  `rss_cache` int(10) unsigned NOT NULL DEFAULT '0',
  `rss_feed` text,
  `rss_template` varchar(64) NOT NULL DEFAULT '',
  `numberOfItems` smallint(5) unsigned NOT NULL DEFAULT '0',
  `disableCaptcha` char(1) NOT NULL DEFAULT '',
  `reg_groups` blob,
  `reg_allowLogin` char(1) NOT NULL DEFAULT '',
  `reg_skipName` char(1) NOT NULL DEFAULT '',
  `reg_close` varchar(32) NOT NULL DEFAULT '',
  `reg_assignDir` char(1) NOT NULL DEFAULT '',
  `reg_homeDir` binary(16) DEFAULT NULL,
  `reg_activate` char(1) NOT NULL DEFAULT '',
  `reg_jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_text` text,
  `reg_password` text,
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `guests` char(1) NOT NULL DEFAULT '',
  `cssID` varchar(255) NOT NULL DEFAULT '',
  `space` varchar(64) NOT NULL DEFAULT '',
  `cal_calendar` blob,
  `cal_noSpan` char(1) NOT NULL DEFAULT '',
  `cal_startDay` smallint(5) unsigned NOT NULL DEFAULT '1',
  `cal_format` varchar(32) NOT NULL DEFAULT '',
  `cal_ignoreDynamic` char(1) NOT NULL DEFAULT '',
  `cal_order` varchar(32) NOT NULL DEFAULT '',
  `cal_readerModule` int(10) unsigned NOT NULL DEFAULT '0',
  `cal_limit` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cal_template` varchar(64) NOT NULL DEFAULT '',
  `cal_ctemplate` varchar(64) NOT NULL DEFAULT '',
  `cal_showQuantity` char(1) NOT NULL DEFAULT '',
  `com_order` varchar(32) NOT NULL DEFAULT '',
  `com_moderate` char(1) NOT NULL DEFAULT '',
  `com_bbcode` char(1) NOT NULL DEFAULT '',
  `com_requireLogin` char(1) NOT NULL DEFAULT '',
  `com_disableCaptcha` char(1) NOT NULL DEFAULT '',
  `com_template` varchar(64) NOT NULL DEFAULT '',
  `faq_categories` blob,
  `faq_readerModule` int(10) unsigned NOT NULL DEFAULT '0',
  `list_table` varchar(64) NOT NULL DEFAULT '',
  `list_fields` varchar(255) NOT NULL DEFAULT '',
  `list_where` varchar(255) NOT NULL DEFAULT '',
  `list_search` varchar(255) NOT NULL DEFAULT '',
  `list_sort` varchar(255) NOT NULL DEFAULT '',
  `list_info` varchar(255) NOT NULL DEFAULT '',
  `list_info_where` varchar(255) NOT NULL DEFAULT '',
  `list_layout` varchar(64) NOT NULL DEFAULT '',
  `list_info_layout` varchar(64) NOT NULL DEFAULT '',
  `news_archives` blob,
  `news_featured` varchar(16) NOT NULL DEFAULT '',
  `news_jumpToCurrent` varchar(16) NOT NULL DEFAULT '',
  `news_readerModule` int(10) unsigned NOT NULL DEFAULT '0',
  `news_metaFields` varchar(255) NOT NULL DEFAULT '',
  `news_template` varchar(64) NOT NULL DEFAULT '',
  `news_format` varchar(32) NOT NULL DEFAULT '',
  `news_startDay` smallint(5) unsigned NOT NULL DEFAULT '0',
  `news_order` varchar(255) NOT NULL DEFAULT '',
  `news_showQuantity` char(1) NOT NULL DEFAULT '',
  `newsletters` blob,
  `nl_channels` blob,
  `nl_hideChannels` char(1) NOT NULL DEFAULT '',
  `nl_subscribe` text,
  `nl_unsubscribe` text,
  `nl_template` varchar(64) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_module`
--

INSERT INTO `tl_module` (`id`, `pid`, `tstamp`, `name`, `headline`, `type`, `levelOffset`, `showLevel`, `hardLimit`, `showProtected`, `defineRoot`, `rootPage`, `navigationTpl`, `customTpl`, `pages`, `orderPages`, `showHidden`, `customLabel`, `autologin`, `jumpTo`, `redirectBack`, `cols`, `editable`, `memberTpl`, `tableless`, `form`, `queryType`, `fuzzy`, `contextLength`, `totalLength`, `perPage`, `searchType`, `searchTpl`, `inColumn`, `skipFirst`, `loadFirst`, `size`, `transparent`, `flashvars`, `altContent`, `source`, `singleSRC`, `url`, `interactive`, `flashID`, `flashJS`, `imgSize`, `useCaption`, `fullsize`, `multiSRC`, `orderSRC`, `html`, `rss_cache`, `rss_feed`, `rss_template`, `numberOfItems`, `disableCaptcha`, `reg_groups`, `reg_allowLogin`, `reg_skipName`, `reg_close`, `reg_assignDir`, `reg_homeDir`, `reg_activate`, `reg_jumpTo`, `reg_text`, `reg_password`, `protected`, `groups`, `guests`, `cssID`, `space`, `cal_calendar`, `cal_noSpan`, `cal_startDay`, `cal_format`, `cal_ignoreDynamic`, `cal_order`, `cal_readerModule`, `cal_limit`, `cal_template`, `cal_ctemplate`, `cal_showQuantity`, `com_order`, `com_moderate`, `com_bbcode`, `com_requireLogin`, `com_disableCaptcha`, `com_template`, `faq_categories`, `faq_readerModule`, `list_table`, `list_fields`, `list_where`, `list_search`, `list_sort`, `list_info`, `list_info_where`, `list_layout`, `list_info_layout`, `news_archives`, `news_featured`, `news_jumpToCurrent`, `news_readerModule`, `news_metaFields`, `news_template`, `news_format`, `news_startDay`, `news_order`, `news_showQuantity`, `newsletters`, `nl_channels`, `nl_hideChannels`, `nl_subscribe`, `nl_unsubscribe`, `nl_template`) VALUES
(1, 1, 1493896334, 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'a:2:{s:4:"unit";s:2:"h1";s:5:"value";s:0:"";}', 'navigation', 0, 0, '', '', '', 0, 'nav_default', 'mod_headernavigation', NULL, NULL, '', '', '', 0, '', '2cl', NULL, '', '', 0, 'and', '', 48, 1000, 0, 'simple', '', 'main', 0, '', '', '', '', NULL, 'internal', NULL, '', '', '', NULL, '', '', '', NULL, NULL, NULL, 3600, NULL, 'rss_default', 3, '', NULL, '', '', '', '', NULL, '', 0, NULL, NULL, '', NULL, '', 'a:2:{i:0;s:21:"wmfy_headernavigation";i:1;s:0:"";}', 'a:2:{i:0;s:0:"";i:1;s:0:"";}', NULL, '', 1, 'cal_month', '', 'ascending', 0, 0, 'event_full', 'cal_default', '', 'ascending', '', '', '', '', 'com_default', NULL, 0, '', '', '', '', '', '', '', 'list_default', 'info_default', NULL, 'all_items', '', 0, 'a:2:{i:0;s:4:"date";i:1;s:6:"author";}', 'news_latest', 'news_month', 0, 'descending', '', NULL, NULL, '', NULL, NULL, 'nl_simple'),
(2, 1, 1493895424, 'Fußzeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'a:2:{s:4:"unit";s:2:"h1";s:5:"value";s:0:"";}', 'customnav', 0, 0, '', '', '', 0, 'nav_default', 'mod_footernavigation', 0x613a333a7b693a303b693a373b693a313b693a383b693a323b693a393b7d, 0x613a333a7b693a303b733a313a2237223b693a313b733a313a2238223b693a323b733a313a2239223b7d, '', '', '', 0, '', '2cl', NULL, '', '', 0, 'and', '', 48, 1000, 0, 'simple', '', 'main', 0, '', '', '', '', NULL, 'internal', NULL, '', '', '', NULL, '', '', '', NULL, NULL, NULL, 3600, NULL, 'rss_default', 3, '', NULL, '', '', '', '', NULL, '', 0, NULL, NULL, '', NULL, '', 'a:2:{i:0;s:21:"wmfy_footernavigation";i:1;s:0:"";}', 'a:2:{i:0;s:0:"";i:1;s:0:"";}', NULL, '', 1, 'cal_month', '', 'ascending', 0, 0, 'event_full', 'cal_default', '', 'ascending', '', '', '', '', 'com_default', NULL, 0, '', '', '', '', '', '', '', 'list_default', 'info_default', NULL, 'all_items', '', 0, 'a:2:{i:0;s:4:"date";i:1;s:6:"author";}', 'news_latest', 'news_month', 0, 'descending', '', NULL, NULL, '', NULL, NULL, 'nl_simple'),
(3, 1, 1493895714, 'Navigationspfad | Breadcrumb &#40;webmadeforyou&#41;', 'a:2:{s:4:"unit";s:2:"h1";s:5:"value";s:0:"";}', 'breadcrumb', 0, 0, '', '', '', 0, '', 'mod_breadcrumb', NULL, NULL, '', '', '', 0, '', '2cl', NULL, '', '', 0, 'and', '', 48, 1000, 0, 'simple', '', 'main', 0, '', '', '', '', NULL, 'internal', NULL, '', '', '', NULL, '', '', '', NULL, NULL, NULL, 3600, NULL, 'rss_default', 3, '', NULL, '', '', '', '', NULL, '', 0, NULL, NULL, '', NULL, '', 'a:2:{i:0;s:15:"wmfy_breadcrumb";i:1;s:0:"";}', 'a:2:{i:0;s:0:"";i:1;s:0:"";}', NULL, '', 1, 'cal_month', '', 'ascending', 0, 0, 'event_full', 'cal_default', '', 'ascending', '', '', '', '', 'com_default', NULL, 0, '', '', '', '', '', '', '', 'list_default', 'info_default', NULL, 'all_items', '', 0, 'a:2:{i:0;s:4:"date";i:1;s:6:"author";}', 'news_latest', 'news_month', 0, 'descending', '', NULL, NULL, '', NULL, NULL, 'nl_simple');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_news`
--

CREATE TABLE IF NOT EXISTS `tl_news` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `headline` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `author` int(10) unsigned NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `subheadline` varchar(255) NOT NULL DEFAULT '',
  `teaser` text,
  `addImage` char(1) NOT NULL DEFAULT '',
  `singleSRC` binary(16) DEFAULT NULL,
  `alt` varchar(255) NOT NULL DEFAULT '',
  `size` varchar(64) NOT NULL DEFAULT '',
  `imagemargin` varchar(128) NOT NULL DEFAULT '',
  `imageUrl` varchar(255) NOT NULL DEFAULT '',
  `fullsize` char(1) NOT NULL DEFAULT '',
  `caption` varchar(255) NOT NULL DEFAULT '',
  `floating` varchar(12) NOT NULL DEFAULT '',
  `addEnclosure` char(1) NOT NULL DEFAULT '',
  `enclosure` blob,
  `source` varchar(12) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `articleId` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `target` char(1) NOT NULL DEFAULT '',
  `cssClass` varchar(255) NOT NULL DEFAULT '',
  `noComments` char(1) NOT NULL DEFAULT '',
  `featured` char(1) NOT NULL DEFAULT '',
  `published` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_newsletter`
--

CREATE TABLE IF NOT EXISTS `tl_newsletter` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `content` mediumtext,
  `text` mediumtext,
  `addFile` char(1) NOT NULL DEFAULT '',
  `files` blob,
  `template` varchar(64) NOT NULL DEFAULT '',
  `sendText` char(1) NOT NULL DEFAULT '',
  `externalImages` char(1) NOT NULL DEFAULT '',
  `sender` varchar(128) NOT NULL DEFAULT '',
  `senderName` varchar(128) NOT NULL DEFAULT '',
  `sent` char(1) NOT NULL DEFAULT '',
  `date` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_newsletter_channel`
--

CREATE TABLE IF NOT EXISTS `tl_newsletter_channel` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `useSMTP` char(1) NOT NULL DEFAULT '',
  `smtpHost` varchar(64) NOT NULL DEFAULT '',
  `smtpUser` varchar(128) NOT NULL DEFAULT '',
  `smtpPass` varchar(32) NOT NULL DEFAULT '',
  `smtpEnc` varchar(3) NOT NULL DEFAULT '',
  `smtpPort` smallint(5) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_newsletter_recipients`
--

CREATE TABLE IF NOT EXISTS `tl_newsletter_recipients` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  `active` char(1) NOT NULL DEFAULT '',
  `addedOn` varchar(10) NOT NULL DEFAULT '',
  `confirmed` varchar(10) NOT NULL DEFAULT '',
  `ip` varchar(64) NOT NULL DEFAULT '',
  `token` varchar(32) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_news_archive`
--

CREATE TABLE IF NOT EXISTS `tl_news_archive` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `allowComments` char(1) NOT NULL DEFAULT '',
  `notify` varchar(16) NOT NULL DEFAULT '',
  `sortOrder` varchar(32) NOT NULL DEFAULT '',
  `perPage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moderate` char(1) NOT NULL DEFAULT '',
  `bbcode` char(1) NOT NULL DEFAULT '',
  `requireLogin` char(1) NOT NULL DEFAULT '',
  `disableCaptcha` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_news_feed`
--

CREATE TABLE IF NOT EXISTS `tl_news_feed` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `language` varchar(32) NOT NULL DEFAULT '',
  `archives` blob,
  `format` varchar(32) NOT NULL DEFAULT '',
  `source` varchar(32) NOT NULL DEFAULT '',
  `maxItems` smallint(5) unsigned NOT NULL DEFAULT '0',
  `feedBase` varchar(255) NOT NULL DEFAULT '',
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_page`
--

CREATE TABLE IF NOT EXISTS `tl_page` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` varchar(32) NOT NULL DEFAULT '',
  `pageTitle` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(5) NOT NULL DEFAULT '',
  `robots` varchar(32) NOT NULL DEFAULT '',
  `description` text,
  `redirect` varchar(32) NOT NULL DEFAULT '',
  `jumpTo` int(10) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `target` char(1) NOT NULL DEFAULT '',
  `dns` varchar(255) NOT NULL DEFAULT '',
  `staticFiles` varchar(255) NOT NULL DEFAULT '',
  `staticPlugins` varchar(255) NOT NULL DEFAULT '',
  `fallback` char(1) NOT NULL DEFAULT '',
  `adminEmail` varchar(255) NOT NULL DEFAULT '',
  `dateFormat` varchar(32) NOT NULL DEFAULT '',
  `timeFormat` varchar(32) NOT NULL DEFAULT '',
  `datimFormat` varchar(32) NOT NULL DEFAULT '',
  `createSitemap` char(1) NOT NULL DEFAULT '',
  `sitemapName` varchar(32) NOT NULL DEFAULT '',
  `useSSL` char(1) NOT NULL DEFAULT '',
  `autoforward` char(1) NOT NULL DEFAULT '',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `includeLayout` char(1) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT '0',
  `mobileLayout` int(10) unsigned NOT NULL DEFAULT '0',
  `includeCache` char(1) NOT NULL DEFAULT '',
  `cache` int(10) unsigned NOT NULL DEFAULT '0',
  `includeChmod` char(1) NOT NULL DEFAULT '',
  `cuser` int(10) unsigned NOT NULL DEFAULT '0',
  `cgroup` int(10) unsigned NOT NULL DEFAULT '0',
  `chmod` varchar(255) NOT NULL DEFAULT '',
  `noSearch` char(1) NOT NULL DEFAULT '',
  `cssClass` varchar(64) NOT NULL DEFAULT '',
  `sitemap` varchar(32) NOT NULL DEFAULT '',
  `hide` char(1) NOT NULL DEFAULT '',
  `guests` char(1) NOT NULL DEFAULT '',
  `tabindex` smallint(5) unsigned NOT NULL DEFAULT '0',
  `accesskey` char(1) NOT NULL DEFAULT '',
  `published` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_page`
--

INSERT INTO `tl_page` (`id`, `pid`, `sorting`, `tstamp`, `title`, `alias`, `type`, `pageTitle`, `language`, `robots`, `description`, `redirect`, `jumpTo`, `url`, `target`, `dns`, `staticFiles`, `staticPlugins`, `fallback`, `adminEmail`, `dateFormat`, `timeFormat`, `datimFormat`, `createSitemap`, `sitemapName`, `useSSL`, `autoforward`, `protected`, `groups`, `includeLayout`, `layout`, `mobileLayout`, `includeCache`, `cache`, `includeChmod`, `cuser`, `cgroup`, `chmod`, `noSearch`, `cssClass`, `sitemap`, `hide`, `guests`, `tabindex`, `accesskey`, `published`, `start`, `stop`) VALUES
(1, 0, 128, 1493889182, 'Distribution - webmadeforyou', 'distribution-webmadeforyou', 'root', 'Distribution - webmadeforyou', 'de', '', NULL, 'permanent', 0, '', '', '', '', '', '1', 'info@webmadeforyou.de', '', 'dd.mm.yyyy', '', '1', 'sitemap', '', '', '', NULL, '', 0, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', '', '', '', 0, '', '1', '', ''),
(2, 1, 128, 1493891618, 'Seite - 1', 'seite-1', 'regular', 'Seite - 1', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(3, 1, 256, 1493895043, 'Seite - 2', 'seite-2', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(4, 1, 384, 1493895058, 'Seite - 3', 'seite-3', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(5, 1, 512, 1493895074, 'Seite - 4', 'seite-4', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(6, 1, 640, 1493895097, 'Seite - 5', 'seite-5', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(7, 1, 768, 1493895128, 'Footer - 1', 'footer-1', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '1', '', 0, '', '1', '', ''),
(8, 1, 896, 1493895146, 'Footer - 2', 'footer-2', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '1', '', 0, '', '1', '', ''),
(9, 1, 1024, 1493895166, 'Footer - 3', 'footer-3', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '1', '', 0, '', '1', '', ''),
(11, 4, 128, 1493895480, 'Seite - 3 - 1', 'seite-3-1', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', 0, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(12, 4, 256, 1493895492, 'Seite - 3 - 2', 'seite-3-2', 'regular', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', 0, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', 'map_default', '', '', 0, '', '1', '', ''),
(14, 1, 1152, 1493895578, '404', 'seite-nicht-gefunden', 'error_404', '', '', 'index,follow', NULL, 'permanent', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '1', 1, 0, '', 0, '', 0, 0, 'a:9:{i:0;s:2:"u1";i:1;s:2:"u2";i:2;s:2:"u3";i:3;s:2:"u4";i:4;s:2:"u5";i:5;s:2:"u6";i:6;s:2:"g4";i:7;s:2:"g5";i:8;s:2:"g6";}', '', '', '', '', '', 0, '', '1', '', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_repository_installs`
--

CREATE TABLE IF NOT EXISTS `tl_repository_installs` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(32) NOT NULL DEFAULT '',
  `version` int(9) NOT NULL DEFAULT '0',
  `build` int(9) NOT NULL DEFAULT '0',
  `alpha` char(1) NOT NULL DEFAULT '',
  `beta` char(1) NOT NULL DEFAULT '',
  `rc` char(1) NOT NULL DEFAULT '',
  `stable` char(1) NOT NULL DEFAULT '1',
  `lickey` varchar(255) NOT NULL DEFAULT '',
  `delprot` char(1) NOT NULL DEFAULT '',
  `updprot` char(1) NOT NULL DEFAULT '',
  `error` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_repository_instfiles`
--

CREATE TABLE IF NOT EXISTS `tl_repository_instfiles` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filetype` char(1) NOT NULL DEFAULT 'F',
  `flag` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_search`
--

CREATE TABLE IF NOT EXISTS `tl_search` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `text` mediumtext,
  `filesize` double unsigned NOT NULL DEFAULT '0',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `protected` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `language` varchar(5) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_search_index`
--

CREATE TABLE IF NOT EXISTS `tl_search_index` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `word` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `relevance` smallint(5) unsigned NOT NULL DEFAULT '0',
  `language` varchar(5) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_session`
--

CREATE TABLE IF NOT EXISTS `tl_session` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `sessionID` varchar(128) NOT NULL DEFAULT '',
  `hash` varchar(40) DEFAULT NULL,
  `ip` varchar(64) NOT NULL DEFAULT '',
  `su` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_session`
--

INSERT INTO `tl_session` (`id`, `pid`, `tstamp`, `name`, `sessionID`, `hash`, `ip`, `su`) VALUES
(2, 1, 1493896334, 'BE_USER_AUTH', 'ajhfj6kqg9sfovr3jrfp3d4lb2', 'becacffb14b318e728705fedf46ee053f59811d4', '127.0.0.1', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_style`
--

CREATE TABLE IF NOT EXISTS `tl_style` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sorting` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `selector` varchar(1022) NOT NULL DEFAULT '',
  `category` varchar(32) NOT NULL DEFAULT '',
  `comment` varchar(255) NOT NULL DEFAULT '',
  `size` char(1) NOT NULL DEFAULT '',
  `width` varchar(64) NOT NULL DEFAULT '',
  `height` varchar(64) NOT NULL DEFAULT '',
  `minwidth` varchar(64) NOT NULL DEFAULT '',
  `minheight` varchar(64) NOT NULL DEFAULT '',
  `maxwidth` varchar(64) NOT NULL DEFAULT '',
  `maxheight` varchar(64) NOT NULL DEFAULT '',
  `positioning` char(1) NOT NULL DEFAULT '',
  `trbl` varchar(128) NOT NULL DEFAULT '',
  `position` varchar(32) NOT NULL DEFAULT '',
  `floating` varchar(32) NOT NULL DEFAULT '',
  `clear` varchar(32) NOT NULL DEFAULT '',
  `overflow` varchar(32) NOT NULL DEFAULT '',
  `display` varchar(32) NOT NULL DEFAULT '',
  `alignment` char(1) NOT NULL DEFAULT '',
  `margin` varchar(128) NOT NULL DEFAULT '',
  `padding` varchar(128) NOT NULL DEFAULT '',
  `align` varchar(32) NOT NULL DEFAULT '',
  `verticalalign` varchar(32) NOT NULL DEFAULT '',
  `textalign` varchar(32) NOT NULL DEFAULT '',
  `whitespace` varchar(8) NOT NULL DEFAULT '',
  `background` char(1) NOT NULL DEFAULT '',
  `bgcolor` varchar(64) NOT NULL DEFAULT '',
  `bgimage` varchar(255) NOT NULL DEFAULT '',
  `bgposition` varchar(32) NOT NULL DEFAULT '',
  `bgrepeat` varchar(32) NOT NULL DEFAULT '',
  `shadowsize` varchar(128) NOT NULL DEFAULT '',
  `shadowcolor` varchar(64) NOT NULL DEFAULT '',
  `gradientAngle` varchar(32) NOT NULL DEFAULT '',
  `gradientColors` varchar(128) NOT NULL DEFAULT '',
  `border` char(1) NOT NULL DEFAULT '',
  `borderwidth` varchar(128) NOT NULL DEFAULT '',
  `borderstyle` varchar(32) NOT NULL DEFAULT '',
  `bordercolor` varchar(64) NOT NULL DEFAULT '',
  `borderradius` varchar(128) NOT NULL DEFAULT '',
  `bordercollapse` varchar(32) NOT NULL DEFAULT '',
  `borderspacing` varchar(64) NOT NULL DEFAULT '',
  `font` char(1) NOT NULL DEFAULT '',
  `fontfamily` varchar(255) NOT NULL DEFAULT '',
  `fontsize` varchar(64) NOT NULL DEFAULT '',
  `fontcolor` varchar(64) NOT NULL DEFAULT '',
  `lineheight` varchar(64) NOT NULL DEFAULT '',
  `fontstyle` varchar(255) NOT NULL DEFAULT '',
  `texttransform` varchar(32) NOT NULL DEFAULT '',
  `textindent` varchar(64) NOT NULL DEFAULT '',
  `letterspacing` varchar(64) NOT NULL DEFAULT '',
  `wordspacing` varchar(64) NOT NULL DEFAULT '',
  `list` char(1) NOT NULL DEFAULT '',
  `liststyletype` varchar(32) NOT NULL DEFAULT '',
  `liststyleimage` varchar(255) NOT NULL DEFAULT '',
  `own` text,
  `invisible` char(1) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_style_sheet`
--

CREATE TABLE IF NOT EXISTS `tl_style_sheet` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) DEFAULT NULL,
  `disablePie` char(1) NOT NULL DEFAULT '',
  `embedImages` int(10) unsigned NOT NULL DEFAULT '0',
  `cc` varchar(32) NOT NULL DEFAULT '',
  `media` varchar(255) NOT NULL DEFAULT '',
  `mediaQuery` text,
  `vars` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_theme`
--

CREATE TABLE IF NOT EXISTS `tl_theme` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) NOT NULL DEFAULT '',
  `author` varchar(128) NOT NULL DEFAULT '',
  `folders` blob,
  `screenshot` binary(16) DEFAULT NULL,
  `templates` varchar(255) NOT NULL DEFAULT '',
  `vars` text
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_theme`
--

INSERT INTO `tl_theme` (`id`, `tstamp`, `name`, `author`, `folders`, `screenshot`, `templates`, `vars`) VALUES
(1, 1493890043, 'webmadeforyou', 'Ramon Hirsinger', 0x613a313a7b693a303b733a31363a2242e883c130a911e7b6fb54ee75878161223b7d, 0x42e883b030a911e7b6fb54ee75878161, 'templates/templates-webmadeforyou', 'a:0:{}');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_undo`
--

CREATE TABLE IF NOT EXISTS `tl_undo` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `fromTable` varchar(255) NOT NULL DEFAULT '',
  `query` text,
  `affectedRows` smallint(5) unsigned NOT NULL DEFAULT '0',
  `data` mediumblob
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_user`
--

CREATE TABLE IF NOT EXISTS `tl_user` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(5) NOT NULL DEFAULT '',
  `backendTheme` varchar(32) NOT NULL DEFAULT '',
  `uploader` varchar(32) NOT NULL DEFAULT '',
  `showHelp` char(1) NOT NULL DEFAULT '',
  `thumbnails` char(1) NOT NULL DEFAULT '',
  `useRTE` char(1) NOT NULL DEFAULT '',
  `useCE` char(1) NOT NULL DEFAULT '',
  `password` varchar(128) NOT NULL DEFAULT '',
  `pwChange` char(1) NOT NULL DEFAULT '',
  `admin` char(1) NOT NULL DEFAULT '',
  `groups` blob,
  `inherit` varchar(12) NOT NULL DEFAULT '',
  `modules` blob,
  `themes` blob,
  `pagemounts` blob,
  `alpty` blob,
  `filemounts` blob,
  `fop` blob,
  `forms` blob,
  `formp` blob,
  `disable` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `session` blob,
  `dateAdded` int(10) unsigned NOT NULL DEFAULT '0',
  `lastLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `currentLogin` int(10) unsigned NOT NULL DEFAULT '0',
  `loginCount` smallint(5) unsigned NOT NULL DEFAULT '3',
  `locked` int(10) unsigned NOT NULL DEFAULT '0',
  `calendars` blob,
  `calendarp` blob,
  `calendarfeeds` blob,
  `calendarfeedp` blob,
  `faqs` blob,
  `faqp` blob,
  `news` blob,
  `newp` blob,
  `newsfeeds` blob,
  `newsfeedp` blob,
  `newsletters` blob,
  `newsletterp` blob
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_user`
--

INSERT INTO `tl_user` (`id`, `tstamp`, `username`, `name`, `email`, `language`, `backendTheme`, `uploader`, `showHelp`, `thumbnails`, `useRTE`, `useCE`, `password`, `pwChange`, `admin`, `groups`, `inherit`, `modules`, `themes`, `pagemounts`, `alpty`, `filemounts`, `fop`, `forms`, `formp`, `disable`, `start`, `stop`, `session`, `dateAdded`, `lastLogin`, `currentLogin`, `loginCount`, `locked`, `calendars`, `calendarp`, `calendarfeeds`, `calendarfeedp`, `faqs`, `faqp`, `news`, `newp`, `newsfeeds`, `newsfeedp`, `newsletters`, `newsletterp`) VALUES
(1, 1493763367, 'ramon.hirsinger', 'Ramon Hirsinger', 'info@webmadeforyou.de', 'de', 'flexible', '', '1', '1', '1', '1', '$2y$10$GBvKjZCNITxTZ0gd2WADyelAwAZyoVIvfNGeL6J0aA9E.SZjf6VHi', '', '1', NULL, '', NULL, NULL, 0x613a303a7b7d, NULL, 0x613a303a7b7d, NULL, NULL, NULL, '', '', '', 0x613a31373a7b733a373a2272656665726572223b613a32343a7b733a383a223335376231383234223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163303534336637223b7d733a383a226437313638306230223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163303534336637223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a33373a22636f6e74616f2f6d61696e2e7068703f646f3d67726f7570267265663d3335376231383234223b7d733a383a223432376231326165223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163303534336637223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a33373a22636f6e74616f2f6d61696e2e7068703f646f3d67726f7570267265663d3335376231383234223b7d733a383a223430613037393136223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163303534336637223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a33373a22636f6e74616f2f6d61696e2e7068703f646f3d67726f7570267265663d3335376231383234223b7d733a383a223163643539366464223b613a333a7b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a343a226c617374223b733a33373a22636f6e74616f2f6d61696e2e7068703f646f3d67726f7570267265663d3335376231383234223b733a373a2263757272656e74223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3430613037393136223b7d733a383a223933613735336438223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3430613037393136223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b7d733a383a223665626135366135223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3430613037393136223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b7d733a383a226565383266636136223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3430613037393136223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b7d733a383a223235323033373263223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3430613037393136223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b7d733a383a223434343935326138223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d693a303b613a313a7b733a343a226c617374223b733a303a22223b7d693a313b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d733a383a223764653736323232223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d733a383a223139353461383433223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d733a383a226634613530343966223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d733a383a223663356535393233223b613a333a7b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3163643539366464223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b7d733a383a223739663634386635223b613a333a7b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a343a226c617374223b733a34323a22636f6e74616f2f6d61696e2e7068703f646f3d74706c5f656469746f72267265663d3235323033373263223b733a373a2263757272656e74223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3663356535393233223b7d733a383a223130336638383036223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3663356535393233223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3739663634386635223b7d733a383a226363383064303334223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3663356535393233223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3739663634386635223b7d733a383a223863383737333164223b613a333a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3663356535393233223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3739663634386635223b7d733a383a226135643931393832223b613a343a7b733a373a22746c5f70616765223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b733a343a226c617374223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6c61796f75742669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3739663634386635223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a2263757272656e74223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b7d733a383a223937333836373563223b613a343a7b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a22746c5f70616765223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b733a343a226c617374223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b733a373a2263757272656e74223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d6135643931393832223b7d733a383a223334666337636164223b613a343a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d6135643931393832223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a22746c5f70616765223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3937333836373563223b7d733a383a223833373536316230223b613a343a7b733a343a226c617374223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d6135643931393832223b733a383a22746c5f7468656d65223b733a33383a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267265663d3066396333376235223b733a373a22746c5f70616765223b733a33363a22636f6e74616f2f6d61696e2e7068703f646f3d70616765267265663d3863383737333164223b733a373a2263757272656e74223b733a39353a22636f6e74616f2f6d61696e2e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c652669643d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3937333836373563223b7d7d733a32323a227374796c655f73686565745f7570646174655f616c6c223b4e3b733a373a2243555252454e54223b613a313a7b733a333a22494453223b613a333a7b693a303b733a313a2232223b693a313b733a313a2231223b693a323b733a313a2233223b7d7d733a393a22434c4950424f415244223b613a363a7b733a383a22746c5f7468656d65223b613a303a7b7d733a383a22746c5f66696c6573223b613a303a7b7d733a373a22746c5f70616765223b613a303a7b7d733a393a22746c5f6c61796f7574223b613a303a7b7d733a393a22746c5f6d6f64756c65223b613a303a7b7d733a31333a22746c5f757365725f67726f7570223b613a303a7b7d7d733a31313a226e65775f7265636f726473223b613a353a7b733a383a22746c5f7468656d65223b613a313a7b693a303b693a313b7d733a373a22746c5f70616765223b613a31343a7b693a303b693a313b693a313b693a323b693a323b693a333b693a333b693a343b693a343b693a353b693a353b693a363b693a363b693a373b693a373b693a383b693a383b693a393b693a393b693a31303b693a31303b693a31313b693a31313b693a31323b693a31323b693a31333b693a31333b693a31343b7d733a393a22746c5f6c61796f7574223b613a343a7b693a303b693a313b693a313b693a323b693a323b693a333b693a333b693a343b7d733a393a22746c5f6d6f64756c65223b613a343a7b693a303b693a313b693a313b693a323b693a323b693a333b693a333b693a343b7d733a31333a22746c5f757365725f67726f7570223b613a313a7b693a303b693a313b7d7d733a31333a2266696c655069636b6572526566223b733a3131303a22636f6e74616f2f706167652e7068703f646f3d7468656d6573267461626c653d746c5f6d6f64756c65266669656c643d7061676573266163743d73686f772669643d322676616c75653d2672743d3436623164376535373036613761393365313566373433303533653365663238223b733a31323a22706f70757052656665726572223b613a363a7b733a383a223662623635333266223b613a323a7b733a343a226c617374223b733a303a22223b733a373a2263757272656e74223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b7d733a383a223032616338396530223b613a323a7b733a343a226c617374223b733a303a22223b733a373a2263757272656e74223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b7d733a383a226633643763653463223b613a323a7b733a343a226c617374223b733a303a22223b733a373a2263757272656e74223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b7d733a383a223466633439306633223b613a323a7b733a343a226c617374223b733a303a22223b733a373a2263757272656e74223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b7d733a383a223866323439323934223b613a323a7b733a343a226c617374223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b733a373a2263757272656e74223b733a3130343a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d3126666e3d66696c65732f7765626d616465666f72796f752672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3466633439306633223b7d733a383a226636613338336537223b613a323a7b733a343a226c617374223b733a33323a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d31223b733a373a2263757272656e74223b733a38313a22636f6e74616f2f6d61696e2e7068703f646f3d66696c657326706f7075703d312672743d3436623164376535373036613761393365313566373433303533653365663238267265663d3466633439306633223b7d7d733a31333a22746c5f66696c65735f6e6f6465223b733a31393a2266696c65732f7765626d616465666f72796f75223b733a32343a22747265655f746c5f7468656d655f73637265656e73686f74223b613a353a7b733a33323a223639363236373937343730616137623239306165373137633734643966643834223b693a313b733a33323a223863376266653730666464356432646631613834626234353839646661353230223b693a313b733a33323a223539383361353635343930313537393630336430366637633030316339643136223b693a313b733a33323a223165323039633333396361376333353961343431396463373265316364623334223b693a313b733a33323a223538633165613632373066353964386438383139346364313838343464636366223b693a313b7d733a32313a22747265655f746c5f7468656d655f666f6c64657273223b613a323a7b733a33323a223539383361353635343930313537393630336430366637633030316339643136223b693a313b733a33323a223165323039633333396361376333353961343431396463373265316364623334223b693a313b7d733a31353a226669656c647365745f737461746573223b613a343a7b733a373a22746c5f70616765223b613a393a7b733a31333a22676c6f62616c5f6c6567656e64223b693a313b733a31343a22736974656d61705f6c6567656e64223b693a313b733a31363a2270726f7465637465645f6c6567656e64223b693a313b733a31323a2263616368655f6c6567656e64223b693a313b733a31323a2263686d6f645f6c6567656e64223b693a313b733a31343a227075626c6973685f6c6567656e64223b693a313b733a31333a226c61796f75745f6c6567656e64223b693a313b733a31333a227461626e61765f6c6567656e64223b693a313b733a31333a226578706572745f6c6567656e64223b693a313b7d733a31313a22746c5f73657474696e6773223b613a31343a7b733a31323a2270726f78795f6c6567656e64223b693a313b733a31343a22707269766163795f6c6567656e64223b693a313b733a31323a2266696c65735f6c6567656e64223b693a313b733a31343a2275706c6f6164735f6c6567656e64223b693a313b733a31333a227365617263685f6c6567656e64223b693a313b733a31313a22736d74705f6c6567656e64223b693a313b733a31343a226d6f64756c65735f6c6567656e64223b693a313b733a31313a2263726f6e5f6c6567656e64223b693a313b733a31343a2274696d656f75745f6c6567656e64223b693a313b733a31323a2263686d6f645f6c6567656e64223b693a313b733a31333a227570646174655f6c6567656e64223b693a313b733a31373a227265706f7369746f72795f6c6567656e64223b693a313b733a31343a226261636b656e645f6c6567656e64223b693a313b733a31333a22676c6f62616c5f6c6567656e64223b693a313b7d733a393a22746c5f6c61796f7574223b613a363a7b733a31353a2273656374696f6e735f6c6567656e64223b693a313b733a31353a22776562666f6e74735f6c6567656e64223b693a313b733a31383a227069637475726566696c6c5f6c6567656e64223b693a303b733a31333a227363726970745f6c6567656e64223b693a313b733a31333a227374617469635f6c6567656e64223b693a303b733a31333a226578706572745f6c6567656e64223b693a313b7d733a393a22746c5f6d6f64756c65223b613a343a7b733a31353a2274656d706c6174655f6c6567656e64223b693a313b733a31363a227265666572656e63655f6c6567656e64223b693a313b733a31333a226578706572745f6c6567656e64223b693a313b733a31363a2270726f7465637465645f6c6567656e64223b693a313b7d7d733a31323a22746c5f706167655f74726565223b613a31323a7b693a313b693a313b693a323b693a303b693a333b693a303b693a343b693a313b693a353b693a303b693a363b693a303b693a373b693a303b693a383b693a303b693a393b693a303b693a31313b693a303b693a31323b693a303b693a31343b693a303b7d733a31353a22746c5f66696c65735f7069636b6572223b733a33323a2266696c65732f7468656d65732f7468656d652d7765626d616465666f72796f75223b733a31303a2243555252454e545f4944223b733a313a2231223b733a383a2266696c6574726565223b613a313a7b733a383a226131336230333633223b693a313b7d733a32333a22746c5f61727469636c655f746c5f706167655f74726565223b613a313a7b693a313b693a303b7d733a32303a22747265655f746c5f6d6f64756c655f7061676573223b613a313a7b693a313b693a313b7d7d, 1493763367, 1493763400, 1493887098, 3, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_user_group`
--

CREATE TABLE IF NOT EXISTS `tl_user_group` (
  `id` int(10) unsigned NOT NULL,
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `modules` blob,
  `themes` blob,
  `pagemounts` blob,
  `alpty` blob,
  `filemounts` blob,
  `fop` blob,
  `forms` blob,
  `formp` blob,
  `alexf` blob,
  `disable` char(1) NOT NULL DEFAULT '',
  `start` varchar(10) NOT NULL DEFAULT '',
  `stop` varchar(10) NOT NULL DEFAULT '',
  `calendars` blob,
  `calendarp` blob,
  `calendarfeeds` blob,
  `calendarfeedp` blob,
  `faqs` blob,
  `faqp` blob,
  `news` blob,
  `newp` blob,
  `newsfeeds` blob,
  `newsfeedp` blob,
  `newsletters` blob,
  `newsletterp` blob
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tl_version`
--

CREATE TABLE IF NOT EXISTS `tl_version` (
  `id` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `tstamp` int(10) unsigned NOT NULL DEFAULT '0',
  `version` smallint(5) unsigned NOT NULL DEFAULT '1',
  `fromTable` varchar(255) NOT NULL DEFAULT '',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(64) DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `editUrl` varchar(255) NOT NULL DEFAULT '',
  `active` char(1) NOT NULL DEFAULT '',
  `data` mediumblob
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tl_version`
--

INSERT INTO `tl_version` (`id`, `pid`, `tstamp`, `version`, `fromTable`, `userid`, `username`, `description`, `editUrl`, `active`, `data`) VALUES
(1, 1, 1493889543, 1, 'tl_theme', 1, 'ramon.hirsinger', 'webmadeforyou', 'contao/main.php?do=themes&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=e3de2bca', '', 0x613a383a7b733a323a226964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383839323737223b733a343a226e616d65223b733a31333a227765626d616465666f72796f75223b733a363a22617574686f72223b733a31353a2252616d6f6e2048697273696e676572223b733a373a22666f6c64657273223b733a33343a22613a313a7b693a303b733a31363a2242e883c130a911e7b6fb54ee75878161223b7d223b733a31303a2273637265656e73686f74223b733a31363a2242e883b030a911e7b6fb54ee75878161223b733a393a2274656d706c61746573223b733a393a2274656d706c61746573223b733a343a2276617273223b733a363a22613a303a7b7d223b7d),
(2, 1, 1493890043, 2, 'tl_theme', 1, 'ramon.hirsinger', 'webmadeforyou', 'contao/main.php?do=themes&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=e5fd7d37', '1', 0x613a383a7b733a323a226964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383930303336223b733a343a226e616d65223b733a31333a227765626d616465666f72796f75223b733a363a22617574686f72223b733a31353a2252616d6f6e2048697273696e676572223b733a373a22666f6c64657273223b733a33343a22613a313a7b693a303b733a31363a2242e883c130a911e7b6fb54ee75878161223b7d223b733a31303a2273637265656e73686f74223b733a31363a2242e883b030a911e7b6fb54ee75878161223b733a393a2274656d706c61746573223b733a33333a2274656d706c617465732f74656d706c617465732d7765626d616465666f72796f75223b733a343a2276617273223b733a363a22613a303a7b7d223b7d),
(3, 1, 1493890179, 1, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=11eb098b&table=tl_layout&act=edit&id=1', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383930313739223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a303a22223b733a343a22636f6c73223b733a343a2232636c6c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a37363a22613a313a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(4, 1, 1493890183, 2, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=11eb098b&table=tl_layout&act=edit&id=1', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383930313833223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a37363a22613a313a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(5, 1, 1493890202, 3, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=11eb098b&table=tl_layout&act=edit&id=1', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383930323032223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a37363a22613a313a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(6, 1, 1493891438, 4, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3bbeb33f', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383931343338223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3239323a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(7, 1, 1493891593, 5, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=f6e097f4', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383931353933223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3239323a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(8, 2, 1493891598, 1, 'tl_page', 1, 'ramon.hirsinger', 'Seite - 1', 'contao/main.php?do=page&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=37f7d62a', '', 0x613a34383a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a373a22736f7274696e67223b733a333a22313238223b733a363a22747374616d70223b733a31303a2231343933383839323130223b733a353a227469746c65223b733a393a225365697465202d2031223b733a353a22616c696173223b733a373a2273656974652d31223b733a343a2274797065223b733a373a22726567756c6172223b733a393a22706167655469746c65223b733a393a225365697465202d2031223b733a383a226c616e6775616765223b733a303a22223b733a363a22726f626f7473223b733a31323a22696e6465782c666f6c6c6f77223b733a31313a226465736372697074696f6e223b4e3b733a383a227265646972656374223b733a393a227065726d616e656e74223b733a363a226a756d70546f223b733a313a2230223b733a333a2275726c223b733a303a22223b733a363a22746172676574223b733a303a22223b733a333a22646e73223b733a303a22223b733a31313a2273746174696346696c6573223b733a303a22223b733a31333a22737461746963506c7567696e73223b733a303a22223b733a383a2266616c6c6261636b223b733a303a22223b733a31303a2261646d696e456d61696c223b733a303a22223b733a31303a2264617465466f726d6174223b733a303a22223b733a31303a2274696d65466f726d6174223b733a303a22223b733a31313a22646174696d466f726d6174223b733a303a22223b733a31333a22637265617465536974656d6170223b733a303a22223b733a31313a22736974656d61704e616d65223b733a303a22223b733a363a2275736553534c223b733a303a22223b733a31313a226175746f666f7277617264223b733a303a22223b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a31333a22696e636c7564654c61796f7574223b733a303a22223b733a363a226c61796f7574223b733a313a2230223b733a31323a226d6f62696c654c61796f7574223b733a313a2230223b733a31323a22696e636c7564654361636865223b733a303a22223b733a353a226361636865223b733a313a2230223b733a31323a22696e636c75646543686d6f64223b733a303a22223b733a353a226375736572223b733a313a2230223b733a363a226367726f7570223b733a313a2230223b733a353a2263686d6f64223b733a3132333a22613a393a7b693a303b733a323a227531223b693a313b733a323a227532223b693a323b733a323a227533223b693a333b733a323a227534223b693a343b733a323a227535223b693a353b733a323a227536223b693a363b733a323a226734223b693a373b733a323a226735223b693a383b733a323a226736223b7d223b733a383a226e6f536561726368223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a373a22736974656d6170223b733a31313a226d61705f64656661756c74223b733a343a2268696465223b733a303a22223b733a363a22677565737473223b733a303a22223b733a383a22746162696e646578223b733a313a2230223b733a393a226163636573736b6579223b733a303a22223b733a393a227075626c6973686564223b733a313a2231223b733a353a227374617274223b733a303a22223b733a343a2273746f70223b733a303a22223b7d),
(9, 2, 1493891618, 2, 'tl_page', 1, 'ramon.hirsinger', 'Seite - 1', 'contao/main.php?do=page&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=37f7d62a', '1', 0x613a34383a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a373a22736f7274696e67223b733a333a22313238223b733a363a22747374616d70223b733a31303a2231343933383839323130223b733a353a227469746c65223b733a393a225365697465202d2031223b733a353a22616c696173223b733a373a2273656974652d31223b733a343a2274797065223b733a373a22726567756c6172223b733a393a22706167655469746c65223b733a393a225365697465202d2031223b733a383a226c616e6775616765223b733a303a22223b733a363a22726f626f7473223b733a31323a22696e6465782c666f6c6c6f77223b733a31313a226465736372697074696f6e223b4e3b733a383a227265646972656374223b733a393a227065726d616e656e74223b733a363a226a756d70546f223b733a313a2230223b733a333a2275726c223b733a303a22223b733a363a22746172676574223b733a303a22223b733a333a22646e73223b733a303a22223b733a31313a2273746174696346696c6573223b733a303a22223b733a31333a22737461746963506c7567696e73223b733a303a22223b733a383a2266616c6c6261636b223b733a303a22223b733a31303a2261646d696e456d61696c223b733a303a22223b733a31303a2264617465466f726d6174223b733a303a22223b733a31303a2274696d65466f726d6174223b733a303a22223b733a31313a22646174696d466f726d6174223b733a303a22223b733a31333a22637265617465536974656d6170223b733a303a22223b733a31313a22736974656d61704e616d65223b733a303a22223b733a363a2275736553534c223b733a303a22223b733a31313a226175746f666f7277617264223b733a303a22223b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a31333a22696e636c7564654c61796f7574223b733a313a2231223b733a363a226c61796f7574223b733a313a2231223b733a31323a226d6f62696c654c61796f7574223b733a313a2230223b733a31323a22696e636c7564654361636865223b733a303a22223b733a353a226361636865223b733a313a2230223b733a31323a22696e636c75646543686d6f64223b733a303a22223b733a353a226375736572223b733a313a2230223b733a363a226367726f7570223b733a313a2230223b733a353a2263686d6f64223b733a3132333a22613a393a7b693a303b733a323a227531223b693a313b733a323a227532223b693a323b733a323a227533223b693a333b733a323a227534223b693a343b733a323a227535223b693a353b733a323a227536223b693a363b733a323a226734223b693a373b733a323a226735223b693a383b733a323a226736223b7d223b733a383a226e6f536561726368223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a373a22736974656d6170223b733a31313a226d61705f64656661756c74223b733a343a2268696465223b733a303a22223b733a363a22677565737473223b733a303a22223b733a383a22746162696e646578223b733a313a2230223b733a393a226163636573736b6579223b733a303a22223b733a393a227075626c6973686564223b733a313a2231223b733a353a227374617274223b733a303a22223b733a343a2273746f70223b733a303a22223b7d),
(10, 1, 1493891707, 6, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=1c562ec0', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383931373037223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3239323a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(11, 1, 1493894838, 1, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3b93e1c6', '', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934373539223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(12, 1, 1493894857, 2, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3b93e1c6', '', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934373539223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(13, 1, 1493894860, 3, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3b93e1c6', '', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934383537223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(14, 1, 1493894879, 4, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3b93e1c6', '', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934383630223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a31383a226d6f645f686561646e617669676174696f6e223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d);
INSERT INTO `tl_version` (`id`, `pid`, `tstamp`, `version`, `fromTable`, `userid`, `username`, `description`, `editUrl`, `active`, `data`) VALUES
(15, 2, 1493894958, 1, 'tl_module', 1, 'ramon.hirsinger', 'Fußezeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=cc04fe11&table=tl_module&act=edit&id=2', '', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934393537223b733a343a226e616d65223b733a36343a224675c39f657a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(16, 2, 1493894994, 2, 'tl_module', 1, 'ramon.hirsinger', 'Fußezeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=cc04fe11&table=tl_module&act=edit&id=2', '', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934393732223b733a343a226e616d65223b733a36343a224675c39f657a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(17, 2, 1493895219, 3, 'tl_module', 1, 'ramon.hirsinger', 'Fußezeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=04372697', '', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934393937223b733a343a226e616d65223b733a36343a224675c39f657a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(18, 2, 1493895240, 4, 'tl_module', 1, 'ramon.hirsinger', 'Fußezeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=04372697', '', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935323430223b733a343a226e616d65223b733a36343a224675c39f657a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a32303a226d6f645f666f6f7465726e617669676174696f6e223b733a353a227061676573223b733a33303a22613a333a7b693a303b693a373b693a313b693a383b693a323b693a393b7d223b733a31303a226f726465725061676573223b733a34323a22613a333a7b693a303b733a313a2237223b693a313b733a313a2238223b693a323b733a313a2239223b7d223b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(19, 3, 1493895256, 1, 'tl_module', 1, 'ramon.hirsinger', '', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=e04951c1&table=tl_module&act=edit&id=3', '', 0x613a3131363a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935323536223b733a343a226e616d65223b733a303a22223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a2262726561646372756d62223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a303a22223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(20, 3, 1493895344, 2, 'tl_module', 1, 'ramon.hirsinger', 'Navigationspfad | Breadcrumb', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=e04951c1&table=tl_module&act=edit&id=3', '', 0x613a3131363a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935323536223b733a343a226e616d65223b733a32383a224e617669676174696f6e7370666164207c2042726561646372756d62223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a2262726561646372756d62223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a303a22223b733a393a22637573746f6d54706c223b733a31343a226d6f645f62726561646372756d62223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a34343a22613a323a7b693a303b733a303a22223b693a313b733a31353a22776d66795f62726561646372756d62223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(21, 2, 1493895384, 5, 'tl_module', 1, 'ramon.hirsinger', 'Fußezeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=fcd14c53', '', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935323430223b733a343a226e616d65223b733a36343a224675c39f657a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a32303a226d6f645f666f6f7465726e617669676174696f6e223b733a353a227061676573223b733a33303a22613a333a7b693a303b693a373b693a313b693a383b693a323b693a393b7d223b733a31303a226f726465725061676573223b733a34323a22613a333a7b693a303b733a313a2237223b693a313b733a313a2238223b693a323b733a313a2239223b7d223b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a35303a22613a323a7b693a303b733a32313a22776d66795f666f6f7465726e617669676174696f6e223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d);
INSERT INTO `tl_version` (`id`, `pid`, `tstamp`, `version`, `fromTable`, `userid`, `username`, `description`, `editUrl`, `active`, `data`) VALUES
(22, 1, 1493895404, 5, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=c87e04dd', '', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383934383739223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a303a22223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a35303a22613a323a7b693a303b733a32313a22776d66795f6865616465726e617669676174696f6e223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(23, 3, 1493895413, 3, 'tl_module', 1, 'ramon.hirsinger', 'Navigationspfad | Breadcrumb', 'contao/main.php?do=themes&table=tl_module&act=edit&id=3&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=3dcf33d2', '', 0x613a3131363a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935333434223b733a343a226e616d65223b733a32383a224e617669676174696f6e7370666164207c2042726561646372756d62223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a2262726561646372756d62223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a303a22223b733a393a22637573746f6d54706c223b733a31343a226d6f645f62726561646372756d62223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a34343a22613a323a7b693a303b733a31353a22776d66795f62726561646372756d62223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(24, 2, 1493895424, 6, 'tl_module', 1, 'ramon.hirsinger', 'Fußzeilennavigation | Footernavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=2&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=0d30264e', '1', 0x613a3131363a7b733a323a226964223b733a313a2232223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935333930223b733a343a226e616d65223b733a36333a224675c39f7a65696c656e6e617669676174696f6e207c20466f6f7465726e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a393a22637573746f6d6e6176223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a32303a226d6f645f666f6f7465726e617669676174696f6e223b733a353a227061676573223b733a33303a22613a333a7b693a303b693a373b693a313b693a383b693a323b693a393b7d223b733a31303a226f726465725061676573223b733a34323a22613a333a7b693a303b733a313a2237223b693a313b733a313a2238223b693a323b733a313a2239223b7d223b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a35303a22613a323a7b693a303b733a32313a22776d66795f666f6f7465726e617669676174696f6e223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(25, 14, 1493895545, 1, 'tl_page', 1, 'ramon.hirsinger', '404', 'contao/main.php?do=page&mode=1&pid=9&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=344658c2&act=edit&id=14', '', 0x613a34383a7b733a323a226964223b733a323a223134223b733a333a22706964223b733a313a2231223b733a373a22736f7274696e67223b733a343a2231313532223b733a363a22747374616d70223b733a31303a2231343933383935353434223b733a353a227469746c65223b733a333a22343034223b733a353a22616c696173223b733a363a2269642d343034223b733a343a2274797065223b733a393a226572726f725f343034223b733a393a22706167655469746c65223b733a303a22223b733a383a226c616e6775616765223b733a303a22223b733a363a22726f626f7473223b733a31323a22696e6465782c666f6c6c6f77223b733a31313a226465736372697074696f6e223b4e3b733a383a227265646972656374223b733a393a227065726d616e656e74223b733a363a226a756d70546f223b733a313a2230223b733a333a2275726c223b733a303a22223b733a363a22746172676574223b733a303a22223b733a333a22646e73223b733a303a22223b733a31313a2273746174696346696c6573223b733a303a22223b733a31333a22737461746963506c7567696e73223b733a303a22223b733a383a2266616c6c6261636b223b733a303a22223b733a31303a2261646d696e456d61696c223b733a303a22223b733a31303a2264617465466f726d6174223b733a303a22223b733a31303a2274696d65466f726d6174223b733a303a22223b733a31313a22646174696d466f726d6174223b733a303a22223b733a31333a22637265617465536974656d6170223b733a303a22223b733a31313a22736974656d61704e616d65223b733a303a22223b733a363a2275736553534c223b733a303a22223b733a31313a226175746f666f7277617264223b733a303a22223b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a31333a22696e636c7564654c61796f7574223b733a303a22223b733a363a226c61796f7574223b733a313a2230223b733a31323a226d6f62696c654c61796f7574223b733a313a2230223b733a31323a22696e636c7564654361636865223b733a303a22223b733a353a226361636865223b733a313a2230223b733a31323a22696e636c75646543686d6f64223b733a303a22223b733a353a226375736572223b733a313a2230223b733a363a226367726f7570223b733a313a2230223b733a353a2263686d6f64223b733a3132333a22613a393a7b693a303b733a323a227531223b693a313b733a323a227532223b693a323b733a323a227533223b693a333b733a323a227534223b693a343b733a323a227535223b693a353b733a323a227536223b693a363b733a323a226734223b693a373b733a323a226735223b693a383b733a323a226736223b7d223b733a383a226e6f536561726368223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a373a22736974656d6170223b733a303a22223b733a343a2268696465223b733a303a22223b733a363a22677565737473223b733a303a22223b733a383a22746162696e646578223b733a313a2230223b733a393a226163636573736b6579223b733a303a22223b733a393a227075626c6973686564223b733a303a22223b733a353a227374617274223b733a303a22223b733a343a2273746f70223b733a303a22223b7d),
(26, 14, 1493895578, 2, 'tl_page', 1, 'ramon.hirsinger', '404', 'contao/main.php?do=page&mode=1&pid=9&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=344658c2&act=edit&id=14', '1', 0x613a34383a7b733a323a226964223b733a323a223134223b733a333a22706964223b733a313a2231223b733a373a22736f7274696e67223b733a343a2231313532223b733a363a22747374616d70223b733a31303a2231343933383935353434223b733a353a227469746c65223b733a333a22343034223b733a353a22616c696173223b733a32303a2273656974652d6e696368742d676566756e64656e223b733a343a2274797065223b733a393a226572726f725f343034223b733a393a22706167655469746c65223b733a303a22223b733a383a226c616e6775616765223b733a303a22223b733a363a22726f626f7473223b733a31323a22696e6465782c666f6c6c6f77223b733a31313a226465736372697074696f6e223b4e3b733a383a227265646972656374223b733a393a227065726d616e656e74223b733a363a226a756d70546f223b733a313a2230223b733a333a2275726c223b733a303a22223b733a363a22746172676574223b733a303a22223b733a333a22646e73223b733a303a22223b733a31313a2273746174696346696c6573223b733a303a22223b733a31333a22737461746963506c7567696e73223b733a303a22223b733a383a2266616c6c6261636b223b733a303a22223b733a31303a2261646d696e456d61696c223b733a303a22223b733a31303a2264617465466f726d6174223b733a303a22223b733a31303a2274696d65466f726d6174223b733a303a22223b733a31313a22646174696d466f726d6174223b733a303a22223b733a31333a22637265617465536974656d6170223b733a303a22223b733a31313a22736974656d61704e616d65223b733a303a22223b733a363a2275736553534c223b733a303a22223b733a31313a226175746f666f7277617264223b733a303a22223b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a31333a22696e636c7564654c61796f7574223b733a313a2231223b733a363a226c61796f7574223b733a313a2231223b733a31323a226d6f62696c654c61796f7574223b733a313a2230223b733a31323a22696e636c7564654361636865223b733a303a22223b733a353a226361636865223b733a313a2230223b733a31323a22696e636c75646543686d6f64223b733a303a22223b733a353a226375736572223b733a313a2230223b733a363a226367726f7570223b733a313a2230223b733a353a2263686d6f64223b733a3132333a22613a393a7b693a303b733a323a227531223b693a313b733a323a227532223b693a323b733a323a227533223b693a333b733a323a227534223b693a343b733a323a227535223b693a353b733a323a227536223b693a363b733a323a226734223b693a373b733a323a226735223b693a383b733a323a226736223b7d223b733a383a226e6f536561726368223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a373a22736974656d6170223b733a303a22223b733a343a2268696465223b733a303a22223b733a363a22677565737473223b733a303a22223b733a383a22746162696e646578223b733a313a2230223b733a393a226163636573736b6579223b733a303a22223b733a393a227075626c6973686564223b733a313a2231223b733a353a227374617274223b733a303a22223b733a343a2273746f70223b733a303a22223b7d),
(27, 1, 1493895673, 7, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=b9ab5b71', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935363733223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3232303a22613a333a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(28, 1, 1493895686, 8, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=b9ab5b71', '', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935363836223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3330363a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(29, 3, 1493895714, 4, 'tl_module', 1, 'ramon.hirsinger', 'Navigationspfad | Breadcrumb &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=3&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=d85b8c3f', '1', 0x613a3131363a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935343133223b733a343a226e616d65223b733a35323a224e617669676174696f6e7370666164207c2042726561646372756d6220262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a2262726561646372756d62223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a303a22223b733a393a22637573746f6d54706c223b733a31343a226d6f645f62726561646372756d62223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a34343a22613a323a7b693a303b733a31353a22776d66795f62726561646372756d62223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d),
(30, 1, 1493895977, 9, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-100', 'contao/main.php?do=themes&table=tl_layout&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=ee82fca6', '1', 0x613a34303a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935393737223b733a343a226e616d65223b733a31343a226c61796f75742d636f6c2d313030223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a333a2231636c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a303a22223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3330363a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a363a22666f6f746572223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a31313a2266655f706167655f313030223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(31, 3, 1493896119, 1, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-30-70', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=103f8806&table=tl_layout&act=edit&id=3', '', 0x613a34303a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383936313139223b733a343a226e616d65223b733a31363a226c61796f75742d636f6c2d33302d3730223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a303a22223b733a343a22636f6c73223b733a343a2232636c6c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a303a22223b733a393a2273506f736974696f6e223b733a343a226d61696e223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a37363a22613a313a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(32, 3, 1493896184, 2, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-30-70', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=103f8806&table=tl_layout&act=edit&id=3', '', 0x613a34303a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383936313834223b733a343a226e616d65223b733a31363a226c61796f75742d636f6c2d33302d3730223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a343a2232636c6c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3238363a22613a343a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a373a2266655f70616765223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(33, 3, 1493896220, 3, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-30-70', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=103f8806&table=tl_layout&act=edit&id=3', '1', 0x613a34303a7b733a323a226964223b733a313a2233223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383936323230223b733a343a226e616d65223b733a31363a226c61796f75742d636f6c2d33302d3730223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a343a2232636c6c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3337323a22613a353a7b693a303b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226c656674223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a343b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a31333a2266655f706167655f33305f3730223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d);
INSERT INTO `tl_version` (`id`, `pid`, `tstamp`, `version`, `fromTable`, `userid`, `username`, `description`, `editUrl`, `active`, `data`) VALUES
(34, 4, 1493896287, 1, 'tl_layout', 1, 'ramon.hirsinger', 'layout-col-40-60', 'contao/main.php?do=themes&mode=2&pid=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=c34ccf9c&table=tl_layout&act=edit&id=4', '1', 0x613a34303a7b733a323a226964223b733a313a2234223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383936323837223b733a343a226e616d65223b733a31363a226c61796f75742d636f6c2d34302d3630223b733a343a22726f7773223b733a333a22337277223b733a31323a22686561646572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31323a22666f6f746572486569676874223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a343a22636f6c73223b733a343a2232636c6c223b733a393a2277696474684c656674223b733a34333a22613a323a7b733a343a22756e6974223b733a303a22223b733a353a2276616c7565223b733a303a22223b7d223b733a31303a2277696474685269676874223b733a303a22223b733a383a2273656374696f6e73223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a393a2273506f736974696f6e223b733a363a226265666f7265223b733a393a226672616d65776f726b223b733a35343a22613a323a7b693a303b733a31303a226c61796f75742e637373223b693a313b733a31343a22726573706f6e736976652e637373223b7d223b733a31303a227374796c657368656574223b4e3b733a383a2265787465726e616c223b4e3b733a383a226f72646572457874223b733a31373a22613a313a7b693a303b733a303a22223b7d223b733a31323a226c6f6164696e674f72646572223b733a31343a2265787465726e616c5f6669727374223b733a393a226e6577736665656473223b4e3b733a31333a2263616c656e6461726665656473223b4e3b733a373a226d6f64756c6573223b733a3339303a22613a353a7b693a303b613a333a7b733a333a226d6f64223b733a313a2231223b733a333a22636f6c223b733a363a22686561646572223b733a363a22656e61626c65223b733a313a2231223b7d693a313b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226c656674223b733a363a22656e61626c65223b733a313a2231223b7d693a323b613a333a7b733a333a226d6f64223b733a313a2230223b733a333a22636f6c223b733a343a226d61696e223b733a363a22656e61626c65223b733a313a2231223b7d693a333b613a333a7b733a333a226d6f64223b733a313a2233223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d693a343b613a333a7b733a333a226d6f64223b733a313a2232223b733a333a22636f6c223b733a31393a22556e74657220646572204b6f70667a65696c65223b733a363a22656e61626c65223b733a313a2231223b7d7d223b733a383a2274656d706c617465223b733a31333a2266655f706167655f34305f3630223b733a373a22646f6374797065223b733a353a2268746d6c35223b733a383a22776562666f6e7473223b733a303a22223b733a31313a227069637475726566696c6c223b733a303a22223b733a383a2276696577706f7274223b733a303a22223b733a383a227469746c65546167223b733a303a22223b733a383a22637373436c617373223b733a303a22223b733a363a226f6e6c6f6164223b733a303a22223b733a343a2268656164223b4e3b733a393a226164644a5175657279223b733a303a22223b733a373a226a536f75726365223b733a303a22223b733a363a226a7175657279223b4e3b733a31313a226164644d6f6f546f6f6c73223b733a303a22223b733a393a226d6f6f536f75726365223b733a393a226d6f6f5f6c6f63616c223b733a383a226d6f6f746f6f6c73223b4e3b733a393a22616e616c7974696373223b4e3b733a363a22736372697074223b4e3b733a363a22737461746963223b733a303a22223b733a353a227769647468223b733a303a22223b733a353a22616c69676e223b733a363a2263656e746572223b7d),
(35, 1, 1493896334, 6, 'tl_module', 1, 'ramon.hirsinger', 'Kopfnavigation | Headnavigation &#40;webmadeforyou&#41;', 'contao/main.php?do=themes&table=tl_module&act=edit&id=1&rt=46b1d7e5706a7a93e15f743053e3ef28&ref=34fc7cad', '1', 0x613a3131363a7b733a323a226964223b733a313a2231223b733a333a22706964223b733a313a2231223b733a363a22747374616d70223b733a31303a2231343933383935343034223b733a343a226e616d65223b733a35353a224b6f70666e617669676174696f6e207c20486561646e617669676174696f6e20262334303b7765626d616465666f72796f75262334313b223b733a383a22686561646c696e65223b733a34353a22613a323a7b733a343a22756e6974223b733a323a226831223b733a353a2276616c7565223b733a303a22223b7d223b733a343a2274797065223b733a31303a226e617669676174696f6e223b733a31313a226c6576656c4f6666736574223b733a313a2230223b733a393a2273686f774c6576656c223b733a313a2230223b733a393a22686172644c696d6974223b733a303a22223b733a31333a2273686f7750726f746563746564223b733a303a22223b733a31303a22646566696e65526f6f74223b733a303a22223b733a383a22726f6f7450616765223b733a313a2230223b733a31333a226e617669676174696f6e54706c223b733a31313a226e61765f64656661756c74223b733a393a22637573746f6d54706c223b733a32303a226d6f645f6865616465726e617669676174696f6e223b733a353a227061676573223b4e3b733a31303a226f726465725061676573223b4e3b733a31303a2273686f7748696464656e223b733a303a22223b733a31313a22637573746f6d4c6162656c223b733a303a22223b733a393a226175746f6c6f67696e223b733a303a22223b733a363a226a756d70546f223b733a313a2230223b733a31323a2272656469726563744261636b223b733a303a22223b733a343a22636f6c73223b733a333a2232636c223b733a383a226564697461626c65223b4e3b733a393a226d656d62657254706c223b733a303a22223b733a393a227461626c656c657373223b733a303a22223b733a343a22666f726d223b733a313a2230223b733a393a22717565727954797065223b733a333a22616e64223b733a353a2266757a7a79223b733a303a22223b733a31333a22636f6e746578744c656e677468223b733a323a223438223b733a31313a22746f74616c4c656e677468223b733a343a2231303030223b733a373a2270657250616765223b733a313a2230223b733a31303a2273656172636854797065223b733a363a2273696d706c65223b733a393a2273656172636854706c223b733a303a22223b733a383a22696e436f6c756d6e223b733a343a226d61696e223b733a393a22736b69704669727374223b733a313a2230223b733a393a226c6f61644669727374223b733a303a22223b733a343a2273697a65223b733a303a22223b733a31313a227472616e73706172656e74223b733a303a22223b733a393a22666c61736876617273223b733a303a22223b733a31303a22616c74436f6e74656e74223b4e3b733a363a22736f75726365223b733a383a22696e7465726e616c223b733a393a2273696e676c65535243223b4e3b733a333a2275726c223b733a303a22223b733a31313a22696e746572616374697665223b733a303a22223b733a373a22666c6173684944223b733a303a22223b733a373a22666c6173684a53223b4e3b733a373a22696d6753697a65223b733a303a22223b733a31303a2275736543617074696f6e223b733a303a22223b733a383a2266756c6c73697a65223b733a303a22223b733a383a226d756c7469535243223b4e3b733a383a226f72646572535243223b4e3b733a343a2268746d6c223b4e3b733a393a227273735f6361636865223b733a343a2233363030223b733a383a227273735f66656564223b4e3b733a31323a227273735f74656d706c617465223b733a31313a227273735f64656661756c74223b733a31333a226e756d6265724f664974656d73223b733a313a2233223b733a31343a2264697361626c6543617074636861223b733a303a22223b733a31303a227265675f67726f757073223b4e3b733a31343a227265675f616c6c6f774c6f67696e223b733a303a22223b733a31323a227265675f736b69704e616d65223b733a303a22223b733a393a227265675f636c6f7365223b733a303a22223b733a31333a227265675f61737369676e446972223b733a303a22223b733a31313a227265675f686f6d65446972223b4e3b733a31323a227265675f6163746976617465223b733a303a22223b733a31303a227265675f6a756d70546f223b733a313a2230223b733a383a227265675f74657874223b4e3b733a31323a227265675f70617373776f7264223b4e3b733a393a2270726f746563746564223b733a303a22223b733a363a2267726f757073223b4e3b733a363a22677565737473223b733a303a22223b733a353a226373734944223b733a35303a22613a323a7b693a303b733a32313a22776d66795f6865616465726e617669676174696f6e223b693a313b733a303a22223b7d223b733a353a227370616365223b733a32383a22613a323a7b693a303b733a303a22223b693a313b733a303a22223b7d223b733a31323a2263616c5f63616c656e646172223b4e3b733a31303a2263616c5f6e6f5370616e223b733a303a22223b733a31323a2263616c5f7374617274446179223b733a313a2231223b733a31303a2263616c5f666f726d6174223b733a393a2263616c5f6d6f6e7468223b733a31373a2263616c5f69676e6f726544796e616d6963223b733a303a22223b733a393a2263616c5f6f72646572223b733a393a22617363656e64696e67223b733a31363a2263616c5f7265616465724d6f64756c65223b733a313a2230223b733a393a2263616c5f6c696d6974223b733a313a2230223b733a31323a2263616c5f74656d706c617465223b733a31303a226576656e745f66756c6c223b733a31333a2263616c5f6374656d706c617465223b733a31313a2263616c5f64656661756c74223b733a31363a2263616c5f73686f775175616e74697479223b733a303a22223b733a393a22636f6d5f6f72646572223b733a393a22617363656e64696e67223b733a31323a22636f6d5f6d6f646572617465223b733a303a22223b733a31303a22636f6d5f6262636f6465223b733a303a22223b733a31363a22636f6d5f726571756972654c6f67696e223b733a303a22223b733a31383a22636f6d5f64697361626c6543617074636861223b733a303a22223b733a31323a22636f6d5f74656d706c617465223b733a31313a22636f6d5f64656661756c74223b733a31343a226661715f63617465676f72696573223b4e3b733a31363a226661715f7265616465724d6f64756c65223b733a313a2230223b733a31303a226c6973745f7461626c65223b733a303a22223b733a31313a226c6973745f6669656c6473223b733a303a22223b733a31303a226c6973745f7768657265223b733a303a22223b733a31313a226c6973745f736561726368223b733a303a22223b733a393a226c6973745f736f7274223b733a303a22223b733a393a226c6973745f696e666f223b733a303a22223b733a31353a226c6973745f696e666f5f7768657265223b733a303a22223b733a31313a226c6973745f6c61796f7574223b733a31323a226c6973745f64656661756c74223b733a31363a226c6973745f696e666f5f6c61796f7574223b733a31323a22696e666f5f64656661756c74223b733a31333a226e6577735f6172636869766573223b4e3b733a31333a226e6577735f6665617475726564223b733a393a22616c6c5f6974656d73223b733a31383a226e6577735f6a756d70546f43757272656e74223b733a303a22223b733a31373a226e6577735f7265616465724d6f64756c65223b733a313a2230223b733a31353a226e6577735f6d6574614669656c6473223b733a33383a22613a323a7b693a303b733a343a2264617465223b693a313b733a363a22617574686f72223b7d223b733a31333a226e6577735f74656d706c617465223b733a31313a226e6577735f6c6174657374223b733a31313a226e6577735f666f726d6174223b733a31303a226e6577735f6d6f6e7468223b733a31333a226e6577735f7374617274446179223b733a313a2230223b733a31303a226e6577735f6f72646572223b733a31303a2264657363656e64696e67223b733a31373a226e6577735f73686f775175616e74697479223b733a303a22223b733a31313a226e6577736c657474657273223b4e3b733a31313a226e6c5f6368616e6e656c73223b4e3b733a31353a226e6c5f686964654368616e6e656c73223b733a303a22223b733a31323a226e6c5f737562736372696265223b4e3b733a31343a226e6c5f756e737562736372696265223b4e3b733a31313a226e6c5f74656d706c617465223b733a393a226e6c5f73696d706c65223b7d);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `tl_article`
--
ALTER TABLE `tl_article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `pid_start_stop_published_sorting` (`pid`,`start`,`stop`,`published`,`sorting`);

--
-- Indizes für die Tabelle `tl_calendar`
--
ALTER TABLE `tl_calendar`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_calendar_events`
--
ALTER TABLE `tl_calendar_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `pid_start_stop_published` (`pid`,`start`,`stop`,`published`);

--
-- Indizes für die Tabelle `tl_calendar_feed`
--
ALTER TABLE `tl_calendar_feed`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`);

--
-- Indizes für die Tabelle `tl_comments`
--
ALTER TABLE `tl_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `published` (`published`),
  ADD KEY `source_parent_published` (`source`,`parent`,`published`);

--
-- Indizes für die Tabelle `tl_comments_notify`
--
ALTER TABLE `tl_comments_notify`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tokenRemove` (`tokenRemove`),
  ADD KEY `source_parent_tokenConfirm` (`source`,`parent`,`tokenConfirm`);

--
-- Indizes für die Tabelle `tl_content`
--
ALTER TABLE `tl_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid_ptable_invisible_sorting` (`pid`,`ptable`,`invisible`,`sorting`);

--
-- Indizes für die Tabelle `tl_cron`
--
ALTER TABLE `tl_cron`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indizes für die Tabelle `tl_extension`
--
ALTER TABLE `tl_extension`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_faq`
--
ALTER TABLE `tl_faq`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid_published_sorting` (`pid`,`published`,`sorting`);

--
-- Indizes für die Tabelle `tl_faq_category`
--
ALTER TABLE `tl_faq_category`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_files`
--
ALTER TABLE `tl_files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uuid` (`uuid`),
  ADD KEY `pid` (`pid`),
  ADD KEY `path` (`path`(333)),
  ADD KEY `extension` (`extension`);

--
-- Indizes für die Tabelle `tl_form`
--
ALTER TABLE `tl_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`);

--
-- Indizes für die Tabelle `tl_form_field`
--
ALTER TABLE `tl_form_field`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_image_size`
--
ALTER TABLE `tl_image_size`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_image_size_item`
--
ALTER TABLE `tl_image_size_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_layout`
--
ALTER TABLE `tl_layout`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_log`
--
ALTER TABLE `tl_log`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_member`
--
ALTER TABLE `tl_member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `autologin` (`autologin`),
  ADD KEY `email` (`email`),
  ADD KEY `activation` (`activation`);

--
-- Indizes für die Tabelle `tl_member_group`
--
ALTER TABLE `tl_member_group`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_module`
--
ALTER TABLE `tl_module`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_news`
--
ALTER TABLE `tl_news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `pid_start_stop_published` (`pid`,`start`,`stop`,`published`);

--
-- Indizes für die Tabelle `tl_newsletter`
--
ALTER TABLE `tl_newsletter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_newsletter_channel`
--
ALTER TABLE `tl_newsletter_channel`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_newsletter_recipients`
--
ALTER TABLE `tl_newsletter_recipients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`),
  ADD KEY `email` (`email`);

--
-- Indizes für die Tabelle `tl_news_archive`
--
ALTER TABLE `tl_news_archive`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_news_feed`
--
ALTER TABLE `tl_news_feed`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`);

--
-- Indizes für die Tabelle `tl_page`
--
ALTER TABLE `tl_page`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `pid_type_start_stop_published` (`pid`,`type`,`start`,`stop`,`published`);

--
-- Indizes für die Tabelle `tl_repository_installs`
--
ALTER TABLE `tl_repository_installs`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_repository_instfiles`
--
ALTER TABLE `tl_repository_instfiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_search`
--
ALTER TABLE `tl_search`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`),
  ADD UNIQUE KEY `checksum_pid` (`checksum`,`pid`),
  ADD FULLTEXT KEY `text` (`text`);

--
-- Indizes für die Tabelle `tl_search_index`
--
ALTER TABLE `tl_search_index`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`),
  ADD KEY `word` (`word`);

--
-- Indizes für die Tabelle `tl_session`
--
ALTER TABLE `tl_session`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_style`
--
ALTER TABLE `tl_style`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`);

--
-- Indizes für die Tabelle `tl_style_sheet`
--
ALTER TABLE `tl_style_sheet`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indizes für die Tabelle `tl_theme`
--
ALTER TABLE `tl_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_undo`
--
ALTER TABLE `tl_undo`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_user`
--
ALTER TABLE `tl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `email` (`email`);

--
-- Indizes für die Tabelle `tl_user_group`
--
ALTER TABLE `tl_user_group`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tl_version`
--
ALTER TABLE `tl_version`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pid` (`pid`),
  ADD KEY `fromTable` (`fromTable`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `tl_article`
--
ALTER TABLE `tl_article`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT für Tabelle `tl_calendar`
--
ALTER TABLE `tl_calendar`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_calendar_events`
--
ALTER TABLE `tl_calendar_events`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_calendar_feed`
--
ALTER TABLE `tl_calendar_feed`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_comments`
--
ALTER TABLE `tl_comments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_comments_notify`
--
ALTER TABLE `tl_comments_notify`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_content`
--
ALTER TABLE `tl_content`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_cron`
--
ALTER TABLE `tl_cron`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT für Tabelle `tl_extension`
--
ALTER TABLE `tl_extension`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_faq`
--
ALTER TABLE `tl_faq`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_faq_category`
--
ALTER TABLE `tl_faq_category`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_files`
--
ALTER TABLE `tl_files`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT für Tabelle `tl_form`
--
ALTER TABLE `tl_form`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_form_field`
--
ALTER TABLE `tl_form_field`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_image_size`
--
ALTER TABLE `tl_image_size`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_image_size_item`
--
ALTER TABLE `tl_image_size_item`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_layout`
--
ALTER TABLE `tl_layout`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT für Tabelle `tl_log`
--
ALTER TABLE `tl_log`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=94;
--
-- AUTO_INCREMENT für Tabelle `tl_member`
--
ALTER TABLE `tl_member`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_member_group`
--
ALTER TABLE `tl_member_group`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_module`
--
ALTER TABLE `tl_module`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT für Tabelle `tl_news`
--
ALTER TABLE `tl_news`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_newsletter`
--
ALTER TABLE `tl_newsletter`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_newsletter_channel`
--
ALTER TABLE `tl_newsletter_channel`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_newsletter_recipients`
--
ALTER TABLE `tl_newsletter_recipients`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_news_archive`
--
ALTER TABLE `tl_news_archive`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_news_feed`
--
ALTER TABLE `tl_news_feed`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_page`
--
ALTER TABLE `tl_page`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT für Tabelle `tl_repository_installs`
--
ALTER TABLE `tl_repository_installs`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_repository_instfiles`
--
ALTER TABLE `tl_repository_instfiles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_search`
--
ALTER TABLE `tl_search`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_search_index`
--
ALTER TABLE `tl_search_index`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_session`
--
ALTER TABLE `tl_session`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `tl_style`
--
ALTER TABLE `tl_style`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_style_sheet`
--
ALTER TABLE `tl_style_sheet`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_theme`
--
ALTER TABLE `tl_theme`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `tl_undo`
--
ALTER TABLE `tl_undo`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `tl_user`
--
ALTER TABLE `tl_user`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `tl_user_group`
--
ALTER TABLE `tl_user_group`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `tl_version`
--
ALTER TABLE `tl_version`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
